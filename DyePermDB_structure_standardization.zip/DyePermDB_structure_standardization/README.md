# DyePermDB Structure Standardization Reproducibility Package

Version: `1.0.0`

This repository reproduces the standardized chemical-structure fields used in the public DyePermDB datasets. It contains two complementary workflows:

1. **RDKit-based source-structure standardization workflow**  
   Generates `RDKit_*` fields from source structure fields in the input table.

2. **PubChem CID-based independent structure cross-validation workflow**  
   Retrieves PubChem structures by `PubChem CID`, generates `CIDCV_*` fields, and compares parent structures against the RDKit workflow.

`CIDCV` means **PubChem CID-based Cross-Validation**.

This package performs only chemical-structure standardization and structure-quality control. It does not reassign membrane-permeability labels, modify literature-evidence fields, infer structures from compound names or CAS numbers, or overwrite original PubChem/source fields.

---

## 1. Repository layout

Use the following layout:

```text
DyePermDB_structure_standardization_release_v1_0/
|-- README.md
|-- VERSION.txt
|-- dyepermdb_rdkit_standardization.py
|-- dyepermdb_cidcv_standardization.py
|-- environment.yml
|-- requirements.txt
|-- input/
|-- output/
`-- pubchem_cache/
```

Place the input Excel workbook in `input/` and write generated files to `output/`. The `pubchem_cache/` directory stores PubChem CID lookup results. If a pre-generated `pubchem_cache` is distributed with the dataset release, keep it in this directory and use `--cache-only` for fixed reproduction.

Create the folders in Windows CMD or PowerShell if needed:

```cmd
mkdir input
mkdir output
mkdir pubchem_cache
```

---

## 2. Recommended environment

The release verification environment was:

```text
Python: 3.11.15
RDKit: 2024.09.6
RDKit InChI support: True
RDKit MolStandardize support: True
pandas: 2.2.3
openpyxl: 3.1.5
requests: 2.32.3
```

Create the environment with conda-forge:

```cmd
conda env create -f environment.yml
conda activate dyepermdb-structure-standardization
```

A manual conda command is also possible:

```cmd
conda create -n dyepermdb-structure-standardization -c conda-forge python=3.11 rdkit=2024.09.6 pandas=2.2.3 openpyxl=3.1.5 requests=2.32.3 certifi
conda activate dyepermdb-structure-standardization
```

A pure pip RDKit installation is not recommended as the primary route because InChI support can vary across platforms. If pip is used, verify RDKit and InChI support before running the workflows:

```cmd
python -c "from rdkit import Chem; from rdkit.Chem import inchi; print('RDKit and InChI OK')"
```

---

## 3. Input workbook requirements

The recommended input is the structure-validation dataset, for example:

```text
input\Structure_Validation_Dataset.xlsx
```

The input sheet should contain the following columns:

| Field | RDKit workflow | CIDCV workflow | Notes |
|---|---:|---:|---|
| `Dye_ID` | recommended | recommended | Row identifier for logs and review |
| `SMILES` | recommended | not required | Primary source-structure input for the RDKit workflow |
| `InChI` | optional | not required | Used when SMILES is unavailable or not parseable |
| `PubChem CID` | optional | required | Optional CID lookup for RDKit; core input for CIDCV |
| `RDKit_Parent_InChIKey` | not required | recommended | Used to generate `Parent_Structure_Agreement` |

The scripts recognize common column-name variants. Explicit column names can also be supplied from the command line. Run `--preview-only` before full processing to confirm column detection.

---

## 4. Workflow 1: RDKit source-structure standardization

### 4.1 Input priority

The RDKit workflow constructs molecules in this order:

```text
1. SMILES
2. InChI
3. PubChem CID lookup, only when --allow-pubchem-lookup is enabled
```

The default PubChem fallback mode is `missing-only`. In this mode, PubChem CID lookup is attempted only when no source SMILES/InChI string is available. If a source SMILES/InChI string is present but cannot be parsed, the script does not automatically override that source path with a CID-derived structure.

### 4.2 Output fields

The RDKit workflow writes the following public fields:

```text
RDKit_Parse_Status
RDKit_Input_Source
RDKit_Molecular_Formula
RDKit_Molecular_Weight
RDKit_Exact_Molecular_Weight
RDKit_Formal_Charge
RDKit_InChI
RDKit_InChIKey
RDKit_Canonical_SMILES
RDKit_Isomeric_SMILES
RDKit_Parent_SMILES
RDKit_Parent_InChIKey
RDKit_Parent_Molecular_Formula
RDKit_Parent_Molecular_Weight
RDKit_Parent_Exact_Molecular_Weight
RDKit_Structure_Warning
Structure_Use_Flag
```

If an output column already exists in the input workbook, the script updates that column in place. If it does not exist, the script appends a new column. The console output and run log include a `Public output field completeness` section to confirm that all expected public fields were written.

### 4.3 Preview command

```cmd
python dyepermdb_rdkit_standardization.py --input "input\Structure_Validation_Dataset.xlsx" --sheet "Sheet1" --output "output\Structure_Validation_Dataset_RDKit.xlsx" --allow-pubchem-lookup --cache-dir "pubchem_cache" --preview-only
```

### 4.4 Full run command

```cmd
python dyepermdb_rdkit_standardization.py --input "input\Structure_Validation_Dataset.xlsx" --sheet "Sheet1" --output "output\Structure_Validation_Dataset_RDKit.xlsx" --allow-pubchem-lookup --cache-dir "pubchem_cache" --progress-every 25
```

The run writes:

```text
output\Structure_Validation_Dataset_RDKit.xlsx
output\Structure_Validation_Dataset_RDKit.xlsx.run_log.txt
```

---

## 5. Workflow 2: PubChem CID-based independent structure cross-validation

The CIDCV workflow uses `PubChem CID` only. Compound name and CAS Number are not used for automatic structure inference. The workflow generates `CIDCV_*` fields and compares:

```text
RDKit_Parent_InChIKey vs CIDCV_Parent_InChIKey
```

### 5.1 Output fields

The CIDCV workflow writes the following public fields:

```text
CIDCV_Parse_Status
CIDCV_Input_Source
CIDCV_Molecular_Formula
CIDCV_Molecular_Weight
CIDCV_Exact_Molecular_Weight
CIDCV_Formal_Charge
CIDCV_InChI
CIDCV_InChIKey
CIDCV_Canonical_SMILES
CIDCV_Isomeric_SMILES
CIDCV_Parent_SMILES
CIDCV_Parent_InChIKey
CIDCV_Parent_Molecular_Formula
CIDCV_Parent_Molecular_Weight
CIDCV_Parent_Exact_Molecular_Weight
Parent_Structure_Agreement
```

### 5.2 Preview command

```cmd
python dyepermdb_cidcv_standardization.py --input "output\Structure_Validation_Dataset_RDKit.xlsx" --sheet "Sheet1" --output "output\Structure_Validation_Dataset_RDKit_CIDCV.xlsx" --cache-dir "pubchem_cache" --preview-only
```

### 5.3 Full run command

```cmd
python dyepermdb_cidcv_standardization.py --input "output\Structure_Validation_Dataset_RDKit.xlsx" --sheet "Sheet1" --output "output\Structure_Validation_Dataset_RDKit_CIDCV.xlsx" --cache-dir "pubchem_cache" --progress-every 25
```

The run writes:

```text
output\Structure_Validation_Dataset_RDKit_CIDCV.xlsx
output\Structure_Validation_Dataset_RDKit_CIDCV.xlsx.run_log.txt
```

### 5.4 Fixed reproduction with cache only

If a complete `pubchem_cache` is included in the release, use:

```cmd
python dyepermdb_cidcv_standardization.py --input "output\Structure_Validation_Dataset_RDKit.xlsx" --sheet "Sheet1" --output "output\Structure_Validation_Dataset_RDKit_CIDCV_cacheonly.xlsx" --cache-dir "pubchem_cache" --cache-only --progress-every 25
```

`--cache-only` performs no live PubChem requests and is the preferred mode for exact reproduction of the released dataset.

---

## 6. Parent structure and agreement rules

### 6.1 Parent structure

Parent structures are generated with RDKit MolStandardize / FragmentParent. These fields are intended for structure QC, fingerprints, descriptors, and candidate modelling structures. They do not overwrite original `SMILES`, `InChI`, `InChIKey`, `Molecular Formula`, `Molecular Weight`, or `PubChem CID`, and they should not be interpreted as the experimentally reported chemical form.

AM esters, commercial probes, salt forms, counterions, and multi-fragment records are not rewritten as literature evidence. The scripts only add standardized fields for QC and reproducibility.

### 6.2 `Structure_Use_Flag`

| Value | Meaning |
|---|---|
| `Yes` | Parsed structure with a generated parent structure and no major structural warning |
| `Review` | Parsed structure with salts, multiple fragments, counterions, metals, parent-structure changes, or other features requiring manual review |
| `No` | No reliable parseable structure or no usable structure input |

### 6.3 `Parent_Structure_Agreement`

| Value | Rule |
|---|---|
| `Consistent` | `RDKit_Parent_InChIKey` and `CIDCV_Parent_InChIKey` are identical |
| `Minor Difference` | The first InChIKey connectivity block is identical, but later layers differ |
| `Conflict` | The first InChIKey connectivity block differs |
| `NA` | At least one parent InChIKey is missing |

Records marked `Conflict` require manual review. The scripts do not automatically correct structures.

---

## 7. Reference run summaries

Using the release input table and the recommended environment, the RDKit workflow reference summary is:

```text
Rows processed: 251
RDKit_Parse_Status:
  Parsed                  226
  No structure available   25

RDKit_Input_Source:
  SMILES                                                    222
  PubChem CID lookup                                          4
  No valid PubChem CID                                       21
  Source SMILES/InChI parse failed; PubChem lookup skipped    4

Structure_Use_Flag:
  Review  124
  Yes     102
  No       25
```

The CIDCV workflow reference summary is:

```text
Rows processed: 251
CIDCV lookup/parse summary:
  Parsed                  224
  No PubChem CID           22
  Structure parse failed    5

Parent_Structure_Agreement:
  Consistent        201
  Minor Difference   22
  Conflict            1
  NA                 27
```

PubChem request summaries may differ across computers because of network, SSL, proxy, or cache status. Reproduction should be assessed primarily by the final parse summaries, output field completeness, and `Parent_Structure_Agreement` summary.

---

## 8. PubChem access, SSL, and cache

The scripts support:

```cmd
--pubchem-transport auto
--pubchem-transport requests
--pubchem-transport curl
```

The default `auto` mode first uses Python `requests`. If local certificate settings cause an SSL error, the script can fall back to `curl` / `curl.exe`. If `curl.exe` works but Python `requests` fails, use:

```cmd
--pubchem-transport curl
```

An institutional CA bundle can also be supplied:

```cmd
--ca-bundle "C:\path\to\institution_ca_bundle.pem"
```

`--disable-ssl-verification` is provided for diagnostic use only and is not recommended for release reproduction.

Test PubChem access with:

```cmd
curl.exe "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/2244/property/CanonicalSMILES/JSON"
```

---

## 9. Troubleshooting

### 9.1 Input columns are not detected

Run `--preview-only`. If needed, specify column names explicitly:

```cmd
--smiles-col "SMILES" --inchi-col "InChI" --cid-col "PubChem CID" --id-col "Dye_ID"
```

### 9.2 Output fields are not all appended at the end of the sheet

If a public output field already exists in the input workbook, it is updated in place instead of being duplicated at the end. Check `Public output field completeness` and `Public output field positions` in the console output and run log.

### 9.3 PubChem request summary differs from the reference run

This usually reflects cache state, network access, SSL fallback, or proxy settings. Compare final parse summaries, output field completeness, and `Parent_Structure_Agreement` summary to assess reproducibility.

### 9.4 CIDCV cache-only reports cache miss

The `pubchem_cache` directory is incomplete or not the directory specified by `--cache-dir`. Confirm that the release-provided cache files are present in the correct folder.

---

## 10. Methodological limitations

1. Compound name and CAS Number are not used for automatic structure inference.
2. Membrane-permeability labels are not modified.
3. Original PubChem/source fields are not overwritten.
4. Parent structures are for structure QC, fingerprints, descriptors, and candidate modelling structures; they do not replace the chemical form reported in the literature.
5. Conflict records, metal-containing structures, multi-fragment structures, and unparseable records require manual review.
