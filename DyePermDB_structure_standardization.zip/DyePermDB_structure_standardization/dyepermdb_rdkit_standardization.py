#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DyePermDB public workflow 1:
RDKit-based source-structure standardization workflow

This script regenerates the public RDKit_* structure fields used in DyePermDB.
It preserves all original source columns and appends or updates only the public
standardized output fields listed in PUBLIC_OUTPUT_COLUMNS, including parse-status and input-source fields used for reproducibility diagnostics.

Input priority:
    1. source SMILES
    2. source InChI
    3. optional PubChem CID lookup, only when --allow-pubchem-lookup is used

Compound name and CAS Number are not used for automatic structure inference.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import os
import platform
import re
import sys
import time
from collections import Counter
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests
from openpyxl import load_workbook

from rdkit import Chem, RDLogger, rdBase
from rdkit.Chem import Descriptors, rdMolDescriptors

try:
    from rdkit.Chem import inchi
    HAS_INCHI = True
except Exception:
    inchi = None
    HAS_INCHI = False

try:
    from rdkit.Chem.MolStandardize import rdMolStandardize
    HAS_MOLSTANDARDIZE = True
except Exception:
    rdMolStandardize = None
    HAS_MOLSTANDARDIZE = False

RDLogger.DisableLog("rdApp.*")

SCRIPT_NAME = "dyepermdb_rdkit_standardization.py"
WORKFLOW_NAME = "RDKit-based source-structure standardization workflow"
SCRIPT_VERSION = "1.0.0"

SMILES_CANDIDATES = [
    "SMILES",
    "smiles",
    "Canonical SMILES",
    "Isomeric SMILES",
    "PubChem_SMILES",
    "PubChem Canonical SMILES",
    "PubChem Isomeric SMILES",
]

INCHI_CANDIDATES = [
    "InChI",
    " InChI",
    "Inchi",
    "inchi",
    "PubChem_InChI",
]

CID_CANDIDATES = [
    "PubChem CID",
    "PubChem_CID",
    "CID",
    "pubchem_cid",
]

ID_CANDIDATES = [
    "Dye_ID",
    "Dye ID",
    "ID",
    "Compound ID",
]

PUBLIC_OUTPUT_COLUMNS = [
    "RDKit_Parse_Status",
    "RDKit_Input_Source",
    "RDKit_Molecular_Formula",
    "RDKit_Molecular_Weight",
    "RDKit_Exact_Molecular_Weight",
    "RDKit_Formal_Charge",
    "RDKit_InChI",
    "RDKit_InChIKey",
    "RDKit_Canonical_SMILES",
    "RDKit_Isomeric_SMILES",
    "RDKit_Parent_SMILES",
    "RDKit_Parent_InChIKey",
    "RDKit_Parent_Molecular_Formula",
    "RDKit_Parent_Molecular_Weight",
    "RDKit_Parent_Exact_Molecular_Weight",
    "RDKit_Structure_Warning",
    "Structure_Use_Flag",
]

METAL_ATOMIC_NUMBERS = {
    3, 4, 11, 12, 13, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 55, 56,
    57, 58, 59, 60, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74,
    75, 76, 77, 78, 79, 80, 81, 82, 83, 87, 88, 89, 90, 92
}


def is_blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    text = str(value).strip()
    return text == "" or text.lower() in {"nan", "na", "n/a", "none", "null", "-"}


def clean_text(value: Any) -> str:
    return "" if is_blank(value) else str(value).strip()


def normalize_header(value: Any) -> str:
    return clean_text(value).strip().lower()


def column_letter(index: int) -> str:
    """Convert a 1-based column index to an Excel-style column letter."""
    if not index or index < 1:
        return ""
    letters = []
    while index:
        index, rem = divmod(index - 1, 26)
        letters.append(chr(65 + rem))
    return "".join(reversed(letters))


def output_field_completeness(output_cols: Dict[str, int]) -> Tuple[int, int, List[str]]:
    """Return expected count, found count, and missing public output fields."""
    missing = [field for field in PUBLIC_OUTPUT_COLUMNS if not output_cols.get(field)]
    return len(PUBLIC_OUTPUT_COLUMNS), len(PUBLIC_OUTPUT_COLUMNS) - len(missing), missing


def format_output_field_positions(output_cols: Dict[str, int]) -> List[str]:
    """Format public output field positions for the run log."""
    lines = []
    for field in PUBLIC_OUTPUT_COLUMNS:
        col_idx = output_cols.get(field)
        if col_idx:
            lines.append(f"- {field}: column {column_letter(col_idx)} ({col_idx})")
        else:
            lines.append(f"- {field}: MISSING")
    return lines


def parse_pubchem_cid(value: Any) -> Optional[str]:
    if is_blank(value):
        return None
    text = str(value).strip()
    if re.fullmatch(r"\d+\.0", text):
        text = text[:-2]
    if re.fullmatch(r"\d+", text):
        return text
    return None


def read_headers(ws, header_row: int) -> Dict[str, int]:
    headers: Dict[str, int] = {}
    for col_idx in range(1, ws.max_column + 1):
        name = clean_text(ws.cell(row=header_row, column=col_idx).value)
        if name:
            headers[normalize_header(name)] = col_idx
    return headers


def find_col(headers: Dict[str, int], candidates: Iterable[str], explicit_name: Optional[str] = None) -> Optional[int]:
    if explicit_name:
        col = headers.get(normalize_header(explicit_name))
        if col is not None:
            return col
    for candidate in candidates:
        col = headers.get(normalize_header(candidate))
        if col is not None:
            return col
    return None


def header_name_by_index(ws, col_idx: Optional[int], header_row: int) -> str:
    if not col_idx:
        return ""
    return clean_text(ws.cell(row=header_row, column=col_idx).value)


def ensure_output_columns(ws, header_row: int, output_columns: List[str]) -> Dict[str, int]:
    headers = read_headers(ws, header_row)
    result: Dict[str, int] = {}
    next_col = ws.max_column + 1
    for col_name in output_columns:
        existing = headers.get(normalize_header(col_name))
        if existing:
            result[col_name] = existing
        else:
            ws.cell(row=header_row, column=next_col).value = col_name
            result[col_name] = next_col
            next_col += 1
    return result


def count_nonempty_data_rows(ws, header_row: int) -> int:
    count = 0
    for row_idx in range(header_row + 1, ws.max_row + 1):
        if not all(is_blank(ws.cell(row=row_idx, column=c).value) for c in range(1, ws.max_column + 1)):
            count += 1
    return count


def mol_from_smiles(smiles: str) -> Optional[Chem.Mol]:
    if not smiles:
        return None
    try:
        return Chem.MolFromSmiles(smiles)
    except Exception:
        return None


def mol_from_inchi(inchi_str: str) -> Optional[Chem.Mol]:
    if not inchi_str or not HAS_INCHI:
        return None
    try:
        return Chem.MolFromInchi(inchi_str)
    except Exception:
        return None


def mol_to_inchi_and_key(mol: Chem.Mol) -> Tuple[str, str, str]:
    if not HAS_INCHI:
        return "", "", "RDKit InChI support unavailable"
    try:
        inchi_str = inchi.MolToInchi(mol)
    except Exception:
        return "", "", "MolToInchi failed"
    try:
        inchikey = inchi.InchiToInchiKey(inchi_str) if inchi_str else ""
    except Exception:
        try:
            inchikey = inchi.MolToInchiKey(mol)
        except Exception:
            inchikey = ""
    return inchi_str or "", inchikey or "", ""


def cleanup_mol(mol: Chem.Mol) -> Chem.Mol:
    if not HAS_MOLSTANDARDIZE:
        return Chem.Mol(mol)
    try:
        return rdMolStandardize.Cleanup(mol)
    except Exception:
        return Chem.Mol(mol)


def fragment_parent(mol: Chem.Mol) -> Optional[Chem.Mol]:
    if not HAS_MOLSTANDARDIZE:
        return None
    try:
        return rdMolStandardize.FragmentParent(mol)
    except Exception:
        return None


def count_fragments(mol: Chem.Mol) -> int:
    try:
        return len(Chem.GetMolFrags(mol))
    except Exception:
        return 0


def has_metal(mol: Chem.Mol) -> bool:
    try:
        return any(atom.GetAtomicNum() in METAL_ATOMIC_NUMBERS for atom in mol.GetAtoms())
    except Exception:
        return False


def cache_file_for_cid(cache_dir: Path, cid: str) -> Path:
    return cache_dir / f"pubchem_cid_{cid}.json"



def _parse_pubchem_response_text(text: str) -> Tuple[Dict[str, str], str]:
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return {}, "json-decode-error"
    records = data.get("PropertyTable", {}).get("Properties", [])
    if not records:
        return {}, "empty-response"
    return {k: "" if v is None else str(v) for k, v in records[0].items()}, "ok"


def _save_pubchem_cache(cache_dir: Optional[Path], cid: str, rec: Dict[str, str]) -> None:
    if cache_dir and rec:
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file_for_cid(cache_dir, cid).write_text(
            json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8"
        )


def _curl_get_pubchem_json(url: str, timeout: int, headers: Dict[str, str]) -> Tuple[Dict[str, str], str]:
    """
    Fetch PubChem JSON with curl.

    On Windows, curl.exe often uses the operating-system certificate store. This
    can succeed in institutional environments where Python requests/certifi
    raises an SSLError. The curl fallback is only used for PubChem CID lookup and
    does not change the chemical standardization rules.
    """
    curl_exe = shutil.which("curl.exe") or shutil.which("curl")
    if not curl_exe:
        return {}, "curl-unavailable"

    cmd = [
        curl_exe,
        "-L",
        "--fail",
        "--silent",
        "--show-error",
        "--connect-timeout",
        str(max(1, timeout)),
        "--max-time",
        str(max(1, timeout)),
        "-H",
        f"User-Agent: {headers.get('User-Agent', 'DyePermDB-structure-standardization/1.4')}",
        url,
    ]
    try:
        completed = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=max(1, timeout) + 10,
        )
    except subprocess.TimeoutExpired:
        return {}, "curl-timeout"
    except Exception as exc:
        return {}, f"curl-error:{type(exc).__name__}"

    if completed.returncode != 0:
        stderr = (completed.stderr or "").strip().replace("\n", " ")
        if len(stderr) > 120:
            stderr = stderr[:120] + "..."
        return {}, f"curl-error:{completed.returncode}" + (f":{stderr}" if stderr else "")

    rec, note = _parse_pubchem_response_text(completed.stdout)
    if rec:
        return rec, "network-hit-curl"
    return {}, f"curl-{note}"


def pubchem_cid_lookup(
    cid: str,
    timeout: int,
    cache_dir: Optional[Path],
    cache_only: bool,
    retries: int = 3,
    retry_sleep: float = 1.0,
    transport: str = "auto",
    ca_bundle: Optional[str] = None,
    disable_ssl_verification: bool = False,
) -> Tuple[Dict[str, str], str]:
    """
    Retrieve PubChem structure properties by CID.

    Return value:
        (record, note)

    The note is for the run log and terminal summary only. Network or HTTP
    failures are not written to RDKit_Structure_Warning, because they describe
    the runtime environment rather than a structural problem in the molecule.

    transport:
        auto     - try Python requests first, then curl if requests fails with SSLError
        requests - use Python requests only
        curl     - use curl/curl.exe only
    """
    if cache_dir:
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_file_for_cid(cache_dir, cid)
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return {k: "" if v is None else str(v) for k, v in data.items()}, "cache-hit"
            except Exception:
                pass
        if cache_only:
            return {}, "cache-miss"

    props = "CanonicalSMILES,IsomericSMILES,InChI,InChIKey,MolecularFormula,MolecularWeight"
    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/{props}/JSON"
    headers = {"User-Agent": "DyePermDB-structure-standardization/1.4"}

    transport = (transport or "auto").lower()
    verify: Any = False if disable_ssl_verification else (ca_bundle if ca_bundle else True)

    # curl-only mode is useful on Windows/institutional networks where curl.exe
    # can use the OS certificate store but Python requests cannot validate SSL.
    if transport == "curl":
        last_note = "not-attempted"
        for attempt in range(1, max(1, retries) + 1):
            rec, note = _curl_get_pubchem_json(url, timeout, headers)
            if rec:
                _save_pubchem_cache(cache_dir, cid, rec)
                return rec, note
            last_note = note
            if attempt < max(1, retries) and retry_sleep > 0:
                time.sleep(retry_sleep * attempt)
        return {}, last_note

    last_note = "not-attempted"
    for attempt in range(1, max(1, retries) + 1):
        try:
            response = requests.get(url, headers=headers, timeout=timeout, verify=verify)
            if response.status_code == 200:
                rec, note = _parse_pubchem_response_text(response.text)
                if not rec:
                    return {}, note
                _save_pubchem_cache(cache_dir, cid, rec)
                return rec, "network-hit-requests"

            last_note = f"http-{response.status_code}"
            # Retry only transient server/rate-limit errors.
            if response.status_code not in {408, 429, 500, 502, 503, 504}:
                return {}, last_note

        except requests.exceptions.SSLError:
            last_note = "network-error:SSLError"
            if transport == "auto":
                rec, curl_note = _curl_get_pubchem_json(url, timeout, headers)
                if rec:
                    _save_pubchem_cache(cache_dir, cid, rec)
                    return rec, "network-hit-curl-after-SSLError"
                last_note = f"network-error:SSLError;{curl_note}"

        except requests.exceptions.RequestException as exc:
            last_note = f"network-error:{type(exc).__name__}"
        except Exception as exc:
            last_note = f"error:{type(exc).__name__}"
            return {}, last_note

        if attempt < max(1, retries) and retry_sleep > 0:
            time.sleep(retry_sleep * attempt)

    return {}, last_note


def empty_outputs(
    warning: str,
    use_flag: str = "No",
    parse_status: str = "No structure available",
    input_source: str = "No structure available",
) -> Dict[str, Any]:
    out = {col: "" for col in PUBLIC_OUTPUT_COLUMNS}
    out["RDKit_Parse_Status"] = parse_status
    out["RDKit_Input_Source"] = input_source
    out["RDKit_Structure_Warning"] = warning or "No structure available"
    out["Structure_Use_Flag"] = use_flag
    return out


def standardize_molecule(mol: Chem.Mol, initial_warnings: Optional[List[str]] = None) -> Dict[str, Any]:
    warnings: List[str] = list(initial_warnings or [])
    out = {col: "" for col in PUBLIC_OUTPUT_COLUMNS}

    cleaned = cleanup_mol(mol)
    frag_count = count_fragments(cleaned)

    if frag_count > 1:
        warnings.append("Multiple fragments")
        warnings.append("Salt/counterion present")

    if has_metal(mol) or has_metal(cleaned):
        warnings.append("Metal-containing structure")

    try:
        out["RDKit_Canonical_SMILES"] = Chem.MolToSmiles(cleaned, canonical=True, isomericSmiles=False)
        out["RDKit_Isomeric_SMILES"] = Chem.MolToSmiles(cleaned, canonical=True, isomericSmiles=True)
        out["RDKit_Molecular_Formula"] = rdMolDescriptors.CalcMolFormula(cleaned)
        out["RDKit_Molecular_Weight"] = round(float(Descriptors.MolWt(cleaned)), 6)
        out["RDKit_Exact_Molecular_Weight"] = round(float(Descriptors.ExactMolWt(cleaned)), 6)
        out["RDKit_Formal_Charge"] = int(Chem.GetFormalCharge(cleaned))
        inchi_str, inchikey, inchi_warning = mol_to_inchi_and_key(cleaned)
        out["RDKit_InChI"] = inchi_str
        out["RDKit_InChIKey"] = inchikey
        if inchi_warning:
            warnings.append("InChI generation warning")
    except Exception:
        return empty_outputs("RDKit descriptor generation failed", "No", parse_status="Failed", input_source="Parsed molecule")

    parent = fragment_parent(cleaned)
    if parent is not None:
        try:
            parent_smiles = Chem.MolToSmiles(parent, canonical=True, isomericSmiles=True)
            out["RDKit_Parent_SMILES"] = parent_smiles
            _, parent_key, parent_inchi_warning = mol_to_inchi_and_key(parent)
            out["RDKit_Parent_InChIKey"] = parent_key
            out["RDKit_Parent_Molecular_Formula"] = rdMolDescriptors.CalcMolFormula(parent)
            out["RDKit_Parent_Molecular_Weight"] = round(float(Descriptors.MolWt(parent)), 6)
            out["RDKit_Parent_Exact_Molecular_Weight"] = round(float(Descriptors.ExactMolWt(parent)), 6)
            if parent_inchi_warning:
                warnings.append("Parent InChIKey generation warning")
            if parent_smiles and parent_smiles != out.get("RDKit_Isomeric_SMILES", ""):
                warnings.append("Parent structure generated")
        except Exception:
            warnings.append("Parent descriptor generation failed")
    else:
        warnings.append("Parent structure not generated")

    if "Metal-containing structure" in warnings:
        use_flag = "Review"
    elif "Multiple fragments" in warnings or "Salt/counterion present" in warnings:
        use_flag = "Review"
    elif not out.get("RDKit_Canonical_SMILES"):
        use_flag = "No"
    else:
        use_flag = "Yes"

    out["RDKit_Structure_Warning"] = "; ".join(dict.fromkeys([w for w in warnings if w])) or "OK"
    out["Structure_Use_Flag"] = use_flag
    return out


def choose_input_molecule(
    row_values: Dict[int, Any],
    smiles_col: Optional[int],
    inchi_col: Optional[int],
    cid_col: Optional[int],
    allow_pubchem_lookup: bool,
    pubchem_fallback_mode: str,
    timeout: int,
    cache_dir: Optional[Path],
    cache_only: bool,
    sleep_seconds: float,
    retries: int,
    retry_sleep: float,
    pubchem_transport: str,
    ca_bundle: Optional[str],
    disable_ssl_verification: bool,
    stats: Counter,
    pubchem_stats: Counter,
) -> Tuple[Optional[Chem.Mol], List[str], str]:
    """
    Build an RDKit molecule using the public RDKit workflow input priority.

    Public structural warnings are kept separate from operational PubChem
    lookup diagnostics. If a CID lookup fails because of network/HTTP/cache
    problems, the public output warning becomes "No structure available", while
    the exact lookup status is recorded in the terminal summary and run log.

    pubchem_fallback_mode:
        - missing-only: use CID lookup only if both source SMILES and InChI are blank.
        - missing-or-failed: use CID lookup if source strings are blank or fail parsing.
    """
    warnings: List[str] = []
    smiles_present = False
    inchi_present = False
    source_parse_failed = False
    final_input_source = "No structure available"

    if smiles_col:
        smiles = clean_text(row_values.get(smiles_col))
        if smiles:
            smiles_present = True
            mol = mol_from_smiles(smiles)
            if mol is not None:
                stats["input_source:SMILES"] += 1
                pubchem_stats["lookup-not-needed"] += 1
                return mol, warnings, "SMILES"
            source_parse_failed = True
            stats["smiles_parse_failed"] += 1

    if inchi_col:
        inchi_str = clean_text(row_values.get(inchi_col))
        if inchi_str:
            inchi_present = True
            mol = mol_from_inchi(inchi_str)
            if mol is not None:
                stats["input_source:InChI"] += 1
                pubchem_stats["lookup-not-needed"] += 1
                return mol, warnings, "InChI"
            source_parse_failed = True
            stats["inchi_parse_failed"] += 1

    cid = parse_pubchem_cid(row_values.get(cid_col)) if cid_col else None
    source_missing = (not smiles_present) and (not inchi_present)
    allow_for_this_row = (
        allow_pubchem_lookup
        and cid is not None
        and (
            pubchem_fallback_mode == "missing-or-failed"
            or (pubchem_fallback_mode == "missing-only" and source_missing)
        )
    )

    if allow_for_this_row:
        final_input_source = "PubChem CID lookup attempted"
        pubchem_stats["lookup-attempted"] += 1
        if sleep_seconds > 0:
            time.sleep(sleep_seconds)
        pc, lookup_note = pubchem_cid_lookup(
            cid,
            timeout=timeout,
            cache_dir=cache_dir,
            cache_only=cache_only,
            retries=retries,
            retry_sleep=retry_sleep,
            transport=pubchem_transport,
            ca_bundle=ca_bundle,
            disable_ssl_verification=disable_ssl_verification,
        )
        pubchem_stats[lookup_note] += 1

        if pc:
            for key in ("IsomericSMILES", "CanonicalSMILES"):
                mol = mol_from_smiles(pc.get(key, ""))
                if mol is not None:
                    stats["input_source:PubChem CID lookup"] += 1
                    return mol, warnings, f"PubChem CID lookup ({lookup_note}, {key})"
            mol = mol_from_inchi(pc.get("InChI", ""))
            if mol is not None:
                stats["input_source:PubChem CID lookup"] += 1
                return mol, warnings, f"PubChem CID lookup ({lookup_note}, InChI)"

            pubchem_stats["lookup-structure-parse-failed"] += 1
            final_input_source = "PubChem CID lookup structure parse failed"
        else:
            pubchem_stats["lookup-failed"] += 1
            final_input_source = f"PubChem CID lookup failed ({lookup_note})"
    else:
        if allow_pubchem_lookup and not cid:
            pubchem_stats["lookup-skipped-no-valid-cid"] += 1
            final_input_source = "No valid PubChem CID"
        elif allow_pubchem_lookup and pubchem_fallback_mode == "missing-only" and source_parse_failed and not source_missing:
            pubchem_stats["lookup-skipped-source-string-present-but-unparsed"] += 1
            final_input_source = "Source SMILES/InChI parse failed; PubChem lookup skipped"
        else:
            pubchem_stats["lookup-disabled-or-not-needed"] += 1
            final_input_source = "No structure available"

    # Public output warning should remain structural/data-oriented, not
    # environment-oriented. Detailed parse and PubChem notes are in the run log.
    if source_parse_failed and not source_missing and not allow_for_this_row:
        warnings.append("SMILES/InChI parse failed")
    warnings.append("No structure available")
    return None, list(dict.fromkeys(warnings)), final_input_source


def counter_without_prefix(counter: Counter, prefix: str) -> Counter:
    out = Counter()
    for key, value in counter.items():
        if key.startswith(prefix):
            out[key.split(":", 1)[1]] += value
    return out


def print_counter(title: str, counter: Counter, order: Optional[List[str]] = None, file=None) -> None:
    file = file or sys.stdout
    print(f"\n{title}:", file=file)
    if not counter:
        print("  None", file=file)
        return
    keys: List[str] = []
    if order:
        keys.extend([k for k in order if k in counter])
    keys.extend([k for k, _ in counter.most_common() if k not in keys])
    width = max(len(str(k)) for k in keys) if keys else 10
    for key in keys:
        print(f"  {str(key).ljust(width)}  {counter[key]}", file=file)


def write_run_log(
    log_path: Path,
    args: argparse.Namespace,
    detected: Dict[str, str],
    total_rows: int,
    parse_status_counts: Counter,
    input_source_counts: Counter,
    warning_counts: Counter,
    use_flag_counts: Counter,
    pubchem_counts: Counter,
    issue_rows: List[str],
    output_cols: Dict[str, int],
    started: _dt.datetime,
    ended: _dt.datetime,
) -> None:
    lines: List[str] = []
    append = lines.append
    append("DyePermDB public structure standardization run log")
    append("=" * 70)
    append(f"Workflow: {WORKFLOW_NAME}")
    append(f"Script: {SCRIPT_NAME}")
    append(f"Script version: {SCRIPT_VERSION}")
    append(f"Started: {started.isoformat(timespec='seconds')}")
    append(f"Ended: {ended.isoformat(timespec='seconds')}")
    append(f"Elapsed seconds: {(ended - started).total_seconds():.2f}")
    append("")
    append("Command:")
    append(" ".join(sys.argv))
    append("")
    append("Environment:")
    append(f"Python: {sys.version.replace(os.linesep, ' ')}")
    append(f"Platform: {platform.platform()}")
    append(f"RDKit: {getattr(rdBase, 'rdkitVersion', 'unknown')}")
    append(f"RDKit InChI support: {HAS_INCHI}")
    append(f"RDKit MolStandardize support: {HAS_MOLSTANDARDIZE}")
    try:
        import openpyxl
        append(f"openpyxl: {openpyxl.__version__}")
    except Exception:
        append("openpyxl: unavailable")
    try:
        append(f"requests: {requests.__version__}")
    except Exception:
        append("requests: unavailable")
    append("")
    append("Files and sheet:")
    append(f"Input: {args.input}")
    append(f"Sheet: {args.sheet}")
    append(f"Output: {args.output}")
    append(f"Log: {log_path}")
    append(f"Cache dir: {args.cache_dir or ''}")
    append(f"Cache only: {args.cache_only}")
    append(f"PubChem transport: {args.pubchem_transport}")
    append(f"CA bundle: {args.ca_bundle or ''}")
    append(f"Disable SSL verification: {args.disable_ssl_verification}")
    append(f"Allow PubChem lookup: {args.allow_pubchem_lookup}")
    append(f"PubChem fallback mode: {args.pubchem_fallback_mode}")
    append(f"PubChem retries: {args.retries}")
    append(f"PubChem retry sleep: {args.retry_sleep}")
    append("")
    append("Detected input columns:")
    for key, val in detected.items():
        append(f"- {key}: {val or 'NOT FOUND'}")
    append(f"- Non-empty data rows: {total_rows}")
    append("")
    expected_fields, found_fields, missing_fields = output_field_completeness(output_cols)
    append("Public output field completeness:")
    append(f"- Expected fields: {expected_fields}")
    append(f"- Found fields: {found_fields}")
    append(f"- Missing fields: {len(missing_fields)}")
    if missing_fields:
        append("- Missing field names: " + "; ".join(missing_fields))
    append("")
    append("Public output field positions:")
    for line in format_output_field_positions(output_cols):
        append(line)
    append("")
    def add_counter(title: str, counter: Counter, order: Optional[List[str]] = None) -> None:
        append(f"{title}:")
        if not counter:
            append("  None")
        else:
            keys: List[str] = []
            if order:
                keys.extend([k for k in order if k in counter])
            keys.extend([k for k, _ in counter.most_common() if k not in keys])
            width = max(len(str(k)) for k in keys) if keys else 10
            for key in keys:
                append(f"  {str(key).ljust(width)}  {counter[key]}")
        append("")
    add_counter("QC summary - RDKit parse status", parse_status_counts, ["Parsed", "No structure available"])
    add_counter("RDKit_Input_Source summary", input_source_counts, ["SMILES", "InChI", "PubChem CID lookup", "PubChem CID lookup failed (cache-miss)", "No valid PubChem CID", "No structure available", "Source SMILES/InChI parse failed; PubChem lookup skipped"])
    add_counter("PubChem lookup operational summary", pubchem_counts, ["lookup-not-needed", "lookup-attempted", "cache-hit", "network-hit", "cache-miss", "lookup-failed", "lookup-structure-parse-failed", "lookup-skipped-no-valid-cid", "lookup-skipped-source-string-present-but-unparsed", "lookup-disabled-or-not-needed"])
    add_counter("Structure_Use_Flag summary", use_flag_counts, ["Review", "Yes", "No"])
    add_counter("RDKit_Structure_Warning summary", warning_counts, ["OK", "Multiple fragments", "Salt/counterion present", "Parent structure generated", "Metal-containing structure", "No structure available"])
    append("Rows requiring attention:")
    if issue_rows:
        for item in issue_rows:
            append(f"- {item}")
    else:
        append("- None")
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def print_final_summary(
    output_path: Path,
    log_path: Path,
    parse_status_counts: Counter,
    input_source_counts: Counter,
    pubchem_counts: Counter,
    use_flag_counts: Counter,
    warning_counts: Counter,
    total_rows: int,
    output_cols: Dict[str, int],
) -> None:
    print("\n" + "=" * 72)
    print("RDKit workflow completed")
    print("=" * 72)
    print(f"Rows processed: {total_rows}")
    print_counter("QC summary - RDKit parse status", parse_status_counts, ["Parsed", "No structure available"])
    print_counter("RDKit_Input_Source summary", input_source_counts, ["SMILES", "InChI", "PubChem CID lookup", "PubChem CID lookup failed (cache-miss)", "No valid PubChem CID", "No structure available", "Source SMILES/InChI parse failed; PubChem lookup skipped"])
    print_counter("PubChem lookup operational summary", pubchem_counts, ["lookup-not-needed", "lookup-attempted", "cache-hit", "network-hit", "cache-miss", "lookup-failed", "lookup-structure-parse-failed", "lookup-skipped-no-valid-cid", "lookup-skipped-source-string-present-but-unparsed", "lookup-disabled-or-not-needed"])
    print_counter("Structure_Use_Flag summary", use_flag_counts, ["Review", "Yes", "No"])
    print_counter("RDKit_Structure_Warning summary", warning_counts, ["OK", "Multiple fragments", "Salt/counterion present", "Parent structure generated", "Metal-containing structure", "No structure available"])
    expected_fields, found_fields, missing_fields = output_field_completeness(output_cols)
    print("\nPublic output field completeness:")
    print(f"  Expected fields: {expected_fields}")
    print(f"  Found fields: {found_fields}")
    print(f"  Missing fields: {len(missing_fields)}")
    if missing_fields:
        print("  Missing field names: " + "; ".join(missing_fields))
    print(f"\nOutput workbook: {output_path}")
    print(f"Run log: {log_path}")


def process(args: argparse.Namespace) -> None:
    started = _dt.datetime.now()

    input_path = Path(args.input)
    output_path = Path(args.output)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")
    if input_path.resolve() == output_path.resolve() and not args.allow_overwrite_input:
        raise ValueError("Refusing to overwrite the input workbook. Use a different --output path, or add --allow-overwrite-input.")

    cache_dir = Path(args.cache_dir) if args.cache_dir else None

    wb = load_workbook(input_path)
    if args.sheet not in wb.sheetnames:
        raise ValueError(f"Sheet '{args.sheet}' not found. Available sheets: {', '.join(wb.sheetnames)}")
    ws = wb[args.sheet]

    headers = read_headers(ws, args.header_row)
    smiles_col = find_col(headers, SMILES_CANDIDATES, args.smiles_col)
    inchi_col = find_col(headers, INCHI_CANDIDATES, args.inchi_col)
    cid_col = find_col(headers, CID_CANDIDATES, args.cid_col)
    id_col = find_col(headers, ID_CANDIDATES, args.id_col)

    detected = {
        "row identifier": header_name_by_index(ws, id_col, args.header_row),
        "SMILES": header_name_by_index(ws, smiles_col, args.header_row),
        "InChI": header_name_by_index(ws, inchi_col, args.header_row),
        "PubChem CID": header_name_by_index(ws, cid_col, args.header_row),
    }
    total_rows = count_nonempty_data_rows(ws, args.header_row)

    if args.preview_only:
        print("[Preview only] RDKit workflow")
        print(f"Input: {input_path}")
        print(f"Sheet: {args.sheet}")
        print("Detected columns:")
        for k, v in detected.items():
            print(f"  {k}: {v or 'NOT FOUND'}")
        print(f"Non-empty data rows: {total_rows}")
        print("Public output columns that would be appended or updated:")
        for col in PUBLIC_OUTPUT_COLUMNS:
            print(f"  {col}")
        return

    print("=" * 72)
    print("Starting RDKit workflow")
    print("=" * 72)
    print(f"Input workbook: {input_path}")
    print(f"Worksheet: {args.sheet}")
    print(f"Output workbook: {output_path}")
    print(f"Non-empty data rows: {total_rows}")
    print("Detected columns:")
    for k, v in detected.items():
        print(f"  {k}: {v or 'NOT FOUND'}")
    print(f"PubChem CID lookup enabled: {args.allow_pubchem_lookup}")
    if args.allow_pubchem_lookup:
        print(f"PubChem fallback mode: {args.pubchem_fallback_mode}")
        print(f"PubChem retries: {args.retries}; retry sleep: {args.retry_sleep} second(s)")
    print(f"Progress update interval: every {args.progress_every} row(s)")
    print("-" * 72)

    output_cols = ensure_output_columns(ws, args.header_row, PUBLIC_OUTPUT_COLUMNS)

    parse_status_counts: Counter = Counter()
    warning_counts: Counter = Counter()
    use_flag_counts: Counter = Counter()
    pubchem_counts: Counter = Counter()
    input_source_field_counts: Counter = Counter()
    issue_rows: List[str] = []

    first_data_row = args.header_row + 1
    processed = 0
    for row_idx in range(first_data_row, ws.max_row + 1):
        if all(is_blank(ws.cell(row=row_idx, column=c).value) for c in range(1, ws.max_column + 1)):
            continue

        row_values = {c: ws.cell(row=row_idx, column=c).value for c in range(1, ws.max_column + 1)}
        row_id = clean_text(row_values.get(id_col)) if id_col else f"row {row_idx}"
        processed += 1

        mol, initial_warnings, input_source_for_log = choose_input_molecule(
            row_values=row_values,
            smiles_col=smiles_col,
            inchi_col=inchi_col,
            cid_col=cid_col,
            allow_pubchem_lookup=args.allow_pubchem_lookup,
            pubchem_fallback_mode=args.pubchem_fallback_mode,
            timeout=args.timeout,
            cache_dir=cache_dir,
            cache_only=args.cache_only,
            sleep_seconds=args.sleep_seconds,
            retries=args.retries,
            retry_sleep=args.retry_sleep,
            pubchem_transport=args.pubchem_transport,
            ca_bundle=args.ca_bundle,
            disable_ssl_verification=args.disable_ssl_verification,
            stats=parse_status_counts,
            pubchem_stats=pubchem_counts,
        )

        if mol is None:
            parse_status_counts["No structure available"] += 1
            warning = "; ".join(dict.fromkeys(initial_warnings)) or "No structure available"
            outputs = empty_outputs(
                warning,
                "No",
                parse_status="No structure available",
                input_source=input_source_for_log,
            )
        else:
            parse_status_counts["Parsed"] += 1
            outputs = standardize_molecule(mol, initial_warnings)
            outputs["RDKit_Parse_Status"] = outputs.get("RDKit_Parse_Status") or "Parsed"
            if input_source_for_log.startswith("PubChem CID lookup"):
                outputs["RDKit_Input_Source"] = "PubChem CID lookup"
            else:
                outputs["RDKit_Input_Source"] = input_source_for_log

        for col_name, value in outputs.items():
            ws.cell(row=row_idx, column=output_cols[col_name]).value = value

        input_source_field_counts[clean_text(outputs.get("RDKit_Input_Source")) or ""] += 1
        flag = clean_text(outputs.get("Structure_Use_Flag"))
        warning_text = clean_text(outputs.get("RDKit_Structure_Warning")) or "OK"
        use_flag_counts[flag] += 1
        for part in [p.strip() for p in warning_text.split(";") if p.strip()]:
            warning_counts[part] += 1

        if flag in {"Review", "No"} or warning_text != "OK":
            issue_rows.append(f"{row_id}: input={input_source_for_log}; flag={flag}; warning={warning_text}")

        if (not args.quiet) and args.progress_every > 0 and (processed % args.progress_every == 0 or processed == total_rows):
            pct = (processed / total_rows * 100) if total_rows else 100
            print(
                f"[RDKit progress] {processed}/{total_rows} rows ({pct:.1f}%) | "
                f"Parsed={parse_status_counts['Parsed']} | "
                f"No structure available={parse_status_counts['No structure available']} | "
                f"PubChem attempts={pubchem_counts['lookup-attempted']} | PubChem failures={pubchem_counts['lookup-failed']} | "
                f"Review={use_flag_counts['Review']} | Yes={use_flag_counts['Yes']} | No={use_flag_counts['No']}"
            )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)

    ended = _dt.datetime.now()
    log_path = Path(args.log) if args.log else output_path.with_suffix(output_path.suffix + ".run_log.txt")
    log_path.parent.mkdir(parents=True, exist_ok=True)

    input_source_counts = input_source_field_counts
    # Remove internal prefixed keys before reporting parse status.
    for key in list(parse_status_counts.keys()):
        if ":" in key or key in {"smiles_parse_failed", "inchi_parse_failed", "pubchem_structure_parse_failed", "pubchem_lookup_failed"}:
            del parse_status_counts[key]

    write_run_log(log_path, args, detected, total_rows, parse_status_counts, input_source_counts, warning_counts, use_flag_counts, pubchem_counts, issue_rows, output_cols, started, ended)
    print_final_summary(output_path, log_path, parse_status_counts, input_source_counts, pubchem_counts, use_flag_counts, warning_counts, total_rows, output_cols)

    if pubchem_counts.get("lookup-attempted", 0) and pubchem_counts.get("lookup-failed", 0):
        print("\nWARNING: Some PubChem CID lookups failed. This usually reflects network, proxy, SSL, rate-limit, or cache issues.")
        print("         The exact lookup statuses are recorded in the PubChem lookup operational summary and the run log.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="DyePermDB public RDKit-based source-structure standardization workflow."
    )
    parser.add_argument("--input", required=True, help="Input Excel workbook path.")
    parser.add_argument("--sheet", default="Sheet1", help="Target worksheet name. Default: Sheet1.")
    parser.add_argument("--output", required=True, help="Output Excel workbook path.")
    parser.add_argument("--header-row", type=int, default=1, help="Header row index. Default: 1.")
    parser.add_argument("--smiles-col", default=None, help="Optional explicit source SMILES column name.")
    parser.add_argument("--inchi-col", default=None, help="Optional explicit source InChI column name.")
    parser.add_argument("--cid-col", default=None, help="Optional explicit PubChem CID column name.")
    parser.add_argument("--id-col", default=None, help="Optional explicit row identifier column name, e.g. Dye_ID.")
    parser.add_argument("--allow-pubchem-lookup", action="store_true", help="Allow PubChem CID lookup when a source structure is not available according to the selected fallback mode.")
    parser.add_argument("--pubchem-fallback-mode", choices=["missing-only", "missing-or-failed"], default="missing-only", help="When to use PubChem CID lookup in the RDKit workflow. Default: missing-only.")
    parser.add_argument("--cache-dir", default="pubchem_cache", help="Directory for PubChem CID JSON cache. Default: pubchem_cache.")
    parser.add_argument("--cache-only", action="store_true", help="Use local PubChem cache only; do not query the network.")
    parser.add_argument("--pubchem-transport", choices=["auto", "requests", "curl"], default="auto", help="PubChem HTTP transport. Default: auto. In auto mode, the script tries Python requests first and falls back to curl/curl.exe if requests raises an SSL error.")
    parser.add_argument("--ca-bundle", default=None, help="Optional CA certificate bundle path for Python requests, useful on institutional networks.")
    parser.add_argument("--disable-ssl-verification", action="store_true", help="Troubleshooting only: disable SSL certificate verification for Python requests. Not recommended for final public reproduction.")
    parser.add_argument("--timeout", type=int, default=30, help="PubChem request timeout in seconds. Default: 30.")
    parser.add_argument("--retries", type=int, default=3, help="Number of PubChem request attempts per CID. Default: 3.")
    parser.add_argument("--retry-sleep", type=float, default=1.0, help="Base sleep time between PubChem retry attempts. Default: 1.0.")
    parser.add_argument("--sleep-seconds", type=float, default=0.25, help="Delay between PubChem requests. Default: 0.25.")
    parser.add_argument("--progress-every", type=int, default=25, help="Print progress every N processed rows. Default: 25. Use 1 for row-by-row progress.")
    parser.add_argument("--quiet", action="store_true", help="Suppress progress updates during row processing; final summary is still printed.")
    parser.add_argument("--preview-only", action="store_true", help="Only preview column detection and output fields; do not write an output workbook.")
    parser.add_argument("--log", default=None, help="Optional run log path. Default: <output>.run_log.txt")
    parser.add_argument("--allow-overwrite-input", action="store_true", help="Allow the output path to be the same as the input path. Not recommended.")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        process(args)
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
