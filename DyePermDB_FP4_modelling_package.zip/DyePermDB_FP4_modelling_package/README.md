# DyePermDB FP4 Molecular Fingerprint Modelling Workflow

## Overview

This package provides a reproducible workflow for Open Babel FP4 fingerprint-based binary classification and FP4 bit-importance analysis using fixed DyePermDB train/test split files.

The workflow reads five supplied training/testing split pairs, calculates FP4 molecular fingerprints from `RDKit_Parent_SMILES` using Open Babel / pybel, trains Random Forest and XGBoost classifiers, evaluates training and test sets separately, and exports classification metrics, prediction results, FP4 feature matrices, ROC/PR curve data, FP4 bit-importance tables, trained models, and high-resolution figures.

The FP4 feature dimension is determined from the FP4 feature matrix generated during the current run.

## Package structure

```text
DyePermDB_FP4_modelling_package_EN/
├── 01_fp4_classification_and_bit_importance.py
├── fp4_modelling_utils.py
├── environment.yml
├── requirements.txt
├── README.md
├── SMARTS_InteLigand.txt
└── input/
    ├── split_01_train.xlsx
    ├── split_01_test.xlsx
    ├── split_02_train.xlsx
    ├── split_02_test.xlsx
    ├── split_03_train.xlsx
    ├── split_03_test.xlsx
    ├── split_04_train.xlsx
    ├── split_04_test.xlsx
    ├── split_05_train.xlsx
    └── split_05_test.xlsx
```

`SMARTS_InteLigand.txt` is used by Open Babel for FP4 SMARTS pattern lookup. In this package, it is placed in the same directory as the main script.

## Input files

Place the following ten Excel files in the `input/` directory:

```text
split_01_train.xlsx
split_01_test.xlsx
split_02_train.xlsx
split_02_test.xlsx
split_03_train.xlsx
split_03_test.xlsx
split_04_train.xlsx
split_04_test.xlsx
split_05_train.xlsx
split_05_test.xlsx
```

Each file should contain the following fields:

```text
Dye_ID
Compound name
Intrinsic_Membrane_Permeability_Status
Permeability_Dependency_Context
RDKit_Parent_SMILES
RDKit_Parent_InChIKey
Reference_PMID
Reference_Title
```

Default modelling fields:

```text
Label field:      Intrinsic_Membrane_Permeability_Status
Positive class:   Permeable
Negative class:   Impermeable
Structure field:  RDKit_Parent_SMILES
Leakage field:    RDKit_Parent_InChIKey
```

## Environment setup

Create and activate the conda environment:

```bash
conda env create -f environment.yml
conda activate dyeperm-fp4-modelling
```

Alternatively, install dependencies with pip after preparing a compatible Python environment:

```bash
pip install -r requirements.txt
```

## Environment check

Run the environment check from the package directory, where `SMARTS_InteLigand.txt` is located.

### Windows PowerShell

```powershell
$env:BABEL_DATADIR=(Get-Location).Path
python -c "import os; from openbabel import pybel; pattern_file=os.path.join(os.environ['BABEL_DATADIR'], 'SMARTS_InteLigand.txt'); assert os.path.exists(pattern_file), pattern_file; mol=pybel.readstring('smi','c1ccccc1O'); fp=mol.calcfp('FP4'); assert len(fp.bits) > 0; print('FP4 environment check: OK')"
```

### Windows CMD

```cmd
set BABEL_DATADIR=%CD%
python -c "import os; from openbabel import pybel; pattern_file=os.path.join(os.environ['BABEL_DATADIR'], 'SMARTS_InteLigand.txt'); assert os.path.exists(pattern_file), pattern_file; mol=pybel.readstring('smi','c1ccccc1O'); fp=mol.calcfp('FP4'); assert len(fp.bits) > 0; print('FP4 environment check: OK')"
```

### macOS / Linux

```bash
export BABEL_DATADIR="$(pwd)"
python -c "import os; from openbabel import pybel; pattern_file=os.path.join(os.environ['BABEL_DATADIR'], 'SMARTS_InteLigand.txt'); assert os.path.exists(pattern_file), pattern_file; mol=pybel.readstring('smi','c1ccccc1O'); fp=mol.calcfp('FP4'); assert len(fp.bits) > 0; print('FP4 environment check: OK')"
```

A successful check should include:

```text
FP4 environment check: OK
```

Example output:

```text
FP4 environment check: OK
BABEL_DATADIR=C:\path\to\DyePermDB_FP4_modelling_package_EN
FP4 active bit count=...
```

Run the modelling command in the same terminal session after the environment check.

## Run the workflow

### Windows PowerShell

```powershell
$env:BABEL_DATADIR=(Get-Location).Path
python 01_fp4_classification_and_bit_importance.py --input_dir "input" --output_dir "output" --n_repeats 30
```

### Windows CMD

```cmd
set BABEL_DATADIR=%CD%
python 01_fp4_classification_and_bit_importance.py --input_dir "input" --output_dir "output" --n_repeats 30
```

### macOS / Linux

```bash
export BABEL_DATADIR="$(pwd)"
python 01_fp4_classification_and_bit_importance.py --input_dir "input" --output_dir "output" --n_repeats 30
```

For a quick test run, a smaller number of permutation repeats can be used:

```bash
python 01_fp4_classification_and_bit_importance.py --input_dir "input" --output_dir "output_test" --n_repeats 5
```

## Main command-line options

```text
--input_dir              Directory containing fixed split Excel files
--output_dir             Output directory
--splits                 Split numbers to process, default: 1,2,3,4,5
--label_col              Label column name
--smiles_col             Structure column name
--inchikey_col           Parent InChIKey column for train/test overlap checking
--random_seed            Random seed
--n_repeats              Number of permutation-importance repeats
--n_jobs                 Number of CPU jobs
--rf_n_estimators        Number of Random Forest trees
--xgb_n_estimators       Number of XGBoost boosting rounds
```

## Output directory

The workflow writes outputs to:

```text
output/
├── FP4_classification_results/
├── FP4_bit_importance_results/
├── figures/
│   ├── classification/
│   │   ├── TIFF/
│   │   ├── JPG/
│   │   └── PNG/
│   └── bit_importance/
│       ├── TIFF/
│       ├── JPG/
│       └── PNG/
├── saved_models/
└── logs/
```

## Classification outputs

Random Forest outputs:

```text
fp4_RF_performance_by_split.xlsx
fp4_RF_performance_summary.xlsx
fp4_RF_prediction_results_by_split.xlsx
fp4_RF_confusion_matrix_summary.xlsx
fp4_RF_roc_curve_data.xlsx
fp4_RF_pr_curve_data.xlsx
```

XGBoost outputs:

```text
fp4_XGBoost_performance_by_split.xlsx
fp4_XGBoost_performance_summary.xlsx
fp4_XGBoost_prediction_results_by_split.xlsx
fp4_XGBoost_confusion_matrix_summary.xlsx
fp4_XGBoost_roc_curve_data.xlsx
fp4_XGBoost_pr_curve_data.xlsx
```

Additional classification-related outputs:

```text
fp4_RF_vs_XGBoost_performance_comparison.xlsx
fp4_feature_matrix_by_split.xlsx
fp4_excluded_records_with_reasons.xlsx
fp4_leakage_check.xlsx
fp4_split_label_distribution.xlsx
fp4_fingerprint_length_check.xlsx
fp4_software_environment.xlsx
fp4_modelling_run_log.txt
```

Performance tables include training and test results separately.

Reported metrics include:

```text
ROC-AUC
PR-AUC
Accuracy
Balanced accuracy
F1
MCC
Sensitivity / Recall for Permeable
Specificity / Recall for Impermeable
TN
FP
FN
TP
```

## FP4 bit-importance outputs

```text
fp4_builtin_bit_importance_by_split.xlsx
fp4_permutation_importance_train_by_split.xlsx
fp4_permutation_importance_test_by_split.xlsx
fp4_top10_bits_train_by_split.xlsx
fp4_top10_bits_test_by_split.xlsx
fp4_bit_importance_stability_train.xlsx
fp4_bit_importance_stability_test.xlsx
stable_fp4_bits_train_summary.xlsx
stable_fp4_bits_test_summary.xlsx
```

The workflow reports model-level built-in FP4 bit importance and permutation-based FP4 bit importance. Permutation importance is calculated separately for the training and test sets using ROC-AUC scoring.

## Figures

Classification figures:

```text
RF_ROC_curves_train
RF_ROC_curves_test
RF_PR_curves_train
RF_PR_curves_test
XGBoost_ROC_curves_train
XGBoost_ROC_curves_test
XGBoost_PR_curves_train
XGBoost_PR_curves_test
```

FP4 bit-importance figures include per-split Top 10 FP4 bit plots and cross-split stability plots.

Figures are saved as:

```text
TIFF
JPG
PNG
```

The default figure resolution is 600 dpi.

## Trained models

Trained model files are saved in:

```text
output/saved_models/
```

Expected model files:

```text
split_01_RF.pkl
split_01_XGBoost.pkl
split_02_RF.pkl
split_02_XGBoost.pkl
split_03_RF.pkl
split_03_XGBoost.pkl
split_04_RF.pkl
split_04_XGBoost.pkl
split_05_RF.pkl
split_05_XGBoost.pkl
```

## Key checks after running

Review the following files first:

```text
output/FP4_classification_results/fp4_fingerprint_length_check.xlsx
output/FP4_classification_results/fp4_leakage_check.xlsx
output/FP4_classification_results/fp4_split_label_distribution.xlsx
output/FP4_classification_results/fp4_RF_performance_summary.xlsx
output/FP4_classification_results/fp4_XGBoost_performance_summary.xlsx
output/FP4_bit_importance_results/stable_fp4_bits_test_summary.xlsx
output/logs/fp4_modelling_run_log.txt
```

`fp4_fingerprint_length_check.xlsx` records the observed FP4 bit range, observed unique FP4 bit count, final FP4 feature dimension, Open Babel version, and related notes for the current run.

## Troubleshooting

### `Cannot open SMARTS_InteLigand.txt`

Set `BABEL_DATADIR` to the package directory that contains `SMARTS_InteLigand.txt`, then run the environment check again.

PowerShell:

```powershell
$env:BABEL_DATADIR=(Get-Location).Path
```

CMD:

```cmd
set BABEL_DATADIR=%CD%
```

macOS / Linux:

```bash
export BABEL_DATADIR="$(pwd)"
```

### `ModuleNotFoundError: No module named 'openbabel'`

Activate the conda environment and check the Open Babel installation:

```bash
conda activate dyeperm-fp4-modelling
python -c "from openbabel import pybel; print('Open Babel / pybel import: OK')"
```

### `ModuleNotFoundError: No module named 'xgboost'`

Install XGBoost in the active environment:

```bash
conda install -c conda-forge xgboost
```

or:

```bash
pip install xgboost
```

### No valid FP4 fingerprints generated

Run the environment check and inspect the input column `RDKit_Parent_SMILES` in the split Excel files.
