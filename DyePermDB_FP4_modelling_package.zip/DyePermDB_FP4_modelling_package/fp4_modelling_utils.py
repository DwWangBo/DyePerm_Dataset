#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Utility functions for the DyePermDB FP4 molecular fingerprint modelling workflow.

The functions in this module support fixed train/test split ingestion, Open
Babel FP4 fingerprint generation, model evaluation, ROC/PR curve preparation,
model persistence, and FP4 bit-importance reporting.
"""

from __future__ import annotations

import json
import math
import os
import platform
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd


POSITIVE_LABEL = "Permeable"
NEGATIVE_LABEL = "Impermeable"
VALID_LABELS = {POSITIVE_LABEL, NEGATIVE_LABEL}


MODEL_NAME_LONG = {
    "RF": "Random Forest",
    "XGBoost": "XGBoost",
}


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def split_id_from_number(split_number: int) -> str:
    return f"Split {split_number:02d}"


def split_file_prefix(split_number: int) -> str:
    return f"split_{split_number:02d}"


def bit_name(bit_index: int) -> str:
    """Human-readable FP4 bit label. Uses the original Open Babel bit index."""
    return f"FP4 bit {int(bit_index):03d}"


def internal_bit_col(bit_index: int) -> str:
    """Machine-safe FP4 feature column name."""
    return f"FP4_bit_{int(bit_index):03d}"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def make_output_dirs(output_dir: Path) -> Dict[str, Path]:
    paths = {
        "root": output_dir,
        "classification": output_dir / "FP4_classification_results",
        "importance": output_dir / "FP4_bit_importance_results",
        "fig_class_tiff": output_dir / "figures" / "classification" / "TIFF",
        "fig_class_jpg": output_dir / "figures" / "classification" / "JPG",
        "fig_class_png": output_dir / "figures" / "classification" / "PNG",
        "fig_import_tiff": output_dir / "figures" / "bit_importance" / "TIFF",
        "fig_import_jpg": output_dir / "figures" / "bit_importance" / "JPG",
        "fig_import_png": output_dir / "figures" / "bit_importance" / "PNG",
        "models": output_dir / "saved_models",
        "logs": output_dir / "logs",
    }
    for path in paths.values():
        ensure_dir(path)
    return paths


def init_log(output_dir: Path) -> Path:
    ensure_dir(output_dir / "logs")
    log_path = output_dir / "logs" / "fp4_modelling_run_log.txt"
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(f"[{now_text()}] DyePermDB FP4 molecular fingerprint modelling workflow started.\n")
        f.write("This workflow reads fixed train/test split files and uses the supplied labels and split assignments.\n")
    return log_path


def log_message(log_path: Path, message: str) -> None:
    text = f"[{now_text()}] {message}"
    print(text)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(text + "\n")


def load_openbabel_pybel():
    """
    Import Open Babel / pybel and return (pybel, openbabel_module, version).

    The workflow must fail explicitly if pybel is unavailable because replacing
    The function requests Open Babel FP4 fingerprint calculation.
    """
    try:
        from openbabel import pybel  # type: ignore
        from openbabel import openbabel as ob  # type: ignore
    except Exception as exc:
        raise ImportError(
            "Open Babel / pybel is required for Open Babel FP4 fingerprints. "
            "Install Open Babel from conda-forge, for example: "
            "conda install -c conda-forge openbabel. "
            f"Original import error: {exc}"
        ) from exc

    version = "Unknown"
    for attr in ("OBReleaseVersion", "OB_VERSION"):
        try:
            v = getattr(ob, attr)
            version = v() if callable(v) else str(v)
            break
        except Exception:
            continue

    return pybel, ob, str(version)


def fp4_bits_from_smiles(smiles: str, pybel_module) -> Tuple[List[int], Optional[str]]:
    """
    Calculate Open Babel FP4 bits for a SMILES string.

    Returns (sorted_bits, error_message). bit indices are kept exactly as reported
    by Open Babel/pybel. No fixed length is assumed.
    """
    if pd.isna(smiles) or str(smiles).strip() == "":
        return [], "Missing RDKit_Parent_SMILES"

    smi = str(smiles).strip()
    try:
        mol = pybel_module.readstring("smi", smi)
        # Explicitly request Open Babel FP4.
        fp = mol.calcfp(fptype="FP4")
        bits = sorted({int(b) for b in fp.bits})
        return bits, None
    except Exception as exc:
        return [], f"Open Babel FP4 generation failed: {exc}"


def normalize_column_lookup(df: pd.DataFrame) -> Dict[str, str]:
    """
    Return mapping from lower/stripped column names to original column names.
    Exact names are still preferred; this is only for clear error reporting.
    """
    return {str(c).strip().lower(): c for c in df.columns}


def require_columns(df: pd.DataFrame, required_columns: Sequence[str], file_path: Path) -> None:
    missing = [c for c in required_columns if c not in df.columns]
    if missing:
        lookup = normalize_column_lookup(df)
        suggestions = {}
        for missing_col in missing:
            key = missing_col.strip().lower()
            if key in lookup:
                suggestions[missing_col] = lookup[key]
        suggestion_text = ""
        if suggestions:
            suggestion_text = " Similar stripped/case-insensitive names found: " + json.dumps(
                suggestions, ensure_ascii=False
            )
        raise ValueError(
            f"Required column(s) missing from {file_path}: {missing}."
            f" Available columns: {list(df.columns)}.{suggestion_text} "
            "Use command-line arguments such as --label_col, --smiles_col, "
            "--inchikey_col, --id_col, or --name_col if your column names differ."
        )


def add_or_replace_front_column(df: pd.DataFrame, column: str, value: object) -> pd.DataFrame:
    """
    Put a workflow metadata column at the front of the dataframe.

    If the input split file already contains the same column name, the existing
    values are discarded and replaced with the current workflow value. This is
    intentional for Source_File, Split_ID, and Set_Type because these metadata
    fields are determined by the fixed train/test filename being read.
    """
    out = df.copy()
    if column in out.columns:
        out = out.drop(columns=[column])
    out.insert(0, column, value)
    return out


def read_split_files(
    input_dir: Path,
    split_numbers: Sequence[int],
    required_columns: Sequence[str],
    train_suffix: str = "train",
    test_suffix: str = "test",
) -> Dict[Tuple[str, str], pd.DataFrame]:
    """
    Read fixed split files into a dict keyed by (Split_ID, Set_Type).
    No resplitting is performed.
    """
    data: Dict[Tuple[str, str], pd.DataFrame] = {}
    for split_number in split_numbers:
        split_id = split_id_from_number(split_number)
        prefix = split_file_prefix(split_number)
        for set_type, suffix in [("Train", train_suffix), ("Test", test_suffix)]:
            path = input_dir / f"{prefix}_{suffix}.xlsx"
            if not path.exists():
                raise FileNotFoundError(f"Expected split file was not found: {path}")
            df = pd.read_excel(path)
            require_columns(df, required_columns, path)
            df = df.copy()

            # Split files may already contain workflow metadata columns.
            # These columns are controlled by the fixed train/test filenames and
            # are therefore overwritten to ensure consistent downstream outputs.
            df = add_or_replace_front_column(df, "Set_Type", set_type)
            df = add_or_replace_front_column(df, "Split_ID", split_id)
            df = add_or_replace_front_column(df, "Source_File", path.name)

            data[(split_id, set_type)] = df
    return data


def sanitize_label_series(labels: pd.Series) -> pd.Series:
    return labels.astype(str).str.strip()


def encode_labels(labels: Sequence[str]) -> np.ndarray:
    arr = []
    for label in labels:
        label_str = str(label).strip()
        if label_str == POSITIVE_LABEL:
            arr.append(1)
        elif label_str == NEGATIVE_LABEL:
            arr.append(0)
        else:
            raise ValueError(f"Invalid label encountered: {label!r}")
    return np.asarray(arr, dtype=int)


def label_distribution_rows(
    df: pd.DataFrame,
    label_col: str,
    split_id: str,
    set_type: str,
) -> List[Dict[str, object]]:
    labels = sanitize_label_series(df[label_col])
    counts = labels.value_counts(dropna=False).to_dict()
    total = int(len(df))
    rows = []
    for label in [POSITIVE_LABEL, NEGATIVE_LABEL]:
        count = int(counts.get(label, 0))
        rows.append(
            {
                "Split_ID": split_id,
                "Set_Type": set_type,
                "Label": label,
                "Count": count,
                "Fraction": count / total if total else np.nan,
                "Total_Records": total,
            }
        )
    invalid_count = int(total - sum(int(counts.get(label, 0)) for label in [POSITIVE_LABEL, NEGATIVE_LABEL]))
    if invalid_count:
        rows.append(
            {
                "Split_ID": split_id,
                "Set_Type": set_type,
                "Label": "Invalid_or_missing_label",
                "Count": invalid_count,
                "Fraction": invalid_count / total if total else np.nan,
                "Total_Records": total,
            }
        )
    return rows


def leakage_check_rows(
    train_df: pd.DataFrame,
    test_df: pd.DataFrame,
    inchikey_col: str,
    split_id: str,
) -> List[Dict[str, object]]:
    train_keys = set(
        str(x).strip()
        for x in train_df[inchikey_col].dropna().tolist()
        if str(x).strip() and str(x).strip().lower() != "nan"
    )
    test_keys = set(
        str(x).strip()
        for x in test_df[inchikey_col].dropna().tolist()
        if str(x).strip() and str(x).strip().lower() != "nan"
    )
    shared = sorted(train_keys.intersection(test_keys))
    if not shared:
        return [
            {
                "Split_ID": split_id,
                "Shared_RDKit_Parent_InChIKey": "",
                "Shared_Key_Count": 0,
                "Leakage_Flag": "No shared RDKit_Parent_InChIKey detected",
                "Note": "Shared keys are recorded for review while preserving supplied split assignments.",
            }
        ]
    return [
        {
            "Split_ID": split_id,
            "Shared_RDKit_Parent_InChIKey": key,
            "Shared_Key_Count": len(shared),
            "Leakage_Flag": "Shared RDKit_Parent_InChIKey detected",
            "Note": "Recorded for review while preserving supplied split assignments.",
        }
        for key in shared
    ]


def row_metadata(row: pd.Series, cols: Mapping[str, str]) -> Dict[str, object]:
    out = {}
    for logical_name, col in cols.items():
        if col and col in row.index:
            out[logical_name] = row[col]
    return out


def build_feature_frame_for_records(
    records_df: pd.DataFrame,
    bits_by_row_key: Mapping[Tuple[str, str, int], List[int]],
    global_bits: Sequence[int],
) -> pd.DataFrame:
    rows = []
    bit_to_col = {bit: internal_bit_col(bit) for bit in global_bits}
    global_bit_set = set(global_bits)
    for _, row in records_df.iterrows():
        row_key = (row["Split_ID"], row["Set_Type"], int(row["_Original_Row_Index"]))
        bits = set(bits_by_row_key.get(row_key, []))
        feat = {bit_to_col[bit]: 1 if bit in bits else 0 for bit in global_bits}
        rows.append(feat)
    return pd.DataFrame(rows, columns=[internal_bit_col(bit) for bit in global_bits], dtype=np.int8)


def build_fp4_feature_tables(
    split_data: Mapping[Tuple[str, str], pd.DataFrame],
    pybel_module,
    label_col: str,
    smiles_col: str,
    id_col: str,
    name_col: str,
    inchikey_col: str,
    pmid_col: str,
    title_col: str,
) -> Tuple[pd.DataFrame, Dict[Tuple[str, str, int], List[int]], List[int], pd.DataFrame, pd.DataFrame]:
    """
    Calculate Open Babel FP4 for all fixed split records and create the global
    FP4 bit feature space from observed bits in this workflow.

    Returns:
      valid_records_df, bits_by_row_key, global_bits, excluded_df, raw_augmented_df
    """
    valid_records = []
    excluded_records = []
    all_augmented = []
    bits_by_key: Dict[Tuple[str, str, int], List[int]] = {}
    observed_bits = set()

    metadata_cols = {
        "Dye_ID": id_col,
        "Compound name": name_col,
        "RDKit_Parent_InChIKey": inchikey_col,
        "Reference_PMID": pmid_col,
        "Reference_Title": title_col,
        "RDKit_Parent_SMILES": smiles_col,
        "Intrinsic_Membrane_Permeability_Status": label_col,
    }

    for (split_id, set_type), df in split_data.items():
        for original_row_index, row in df.reset_index(drop=True).iterrows():
            record = {
                "Split_ID": split_id,
                "Set_Type": set_type,
                "_Original_Row_Index": int(original_row_index),
                "Source_File": row.get("Source_File", ""),
            }
            record.update(row_metadata(row, metadata_cols))

            label = str(row[label_col]).strip() if not pd.isna(row[label_col]) else ""
            bits, fp_error = fp4_bits_from_smiles(row[smiles_col], pybel_module)
            valid_label = label in VALID_LABELS

            record["Label_Check"] = "Valid" if valid_label else "Invalid_or_missing_label"
            record["FP4_Status"] = "Generated" if fp_error is None else "Failed"
            record["FP4_Error"] = "" if fp_error is None else fp_error
            record["Observed_Bit_Count_For_Record"] = len(bits)
            record["Observed_Max_Bit_Index_For_Record"] = max(bits) if bits else np.nan

            all_augmented.append(record.copy())

            if not valid_label:
                ex = record.copy()
                ex["Exclusion_Reason"] = (
                    f"Invalid label for binary modelling: {label!r}. "
                    "Only Permeable and Impermeable are encoded for this workflow."
                )
                excluded_records.append(ex)
                continue
            if fp_error is not None:
                ex = record.copy()
                ex["Exclusion_Reason"] = fp_error
                excluded_records.append(ex)
                continue
            if not bits:
                ex = record.copy()
                ex["Exclusion_Reason"] = "Open Babel FP4 generated no active bits"
                excluded_records.append(ex)
                continue

            row_key = (split_id, set_type, int(original_row_index))
            bits_by_key[row_key] = bits
            observed_bits.update(bits)
            valid_records.append(record.copy())

    global_bits = sorted(int(x) for x in observed_bits)
    if not global_bits:
        raise RuntimeError(
            "No valid Open Babel FP4 fingerprints were generated. "
            "Check RDKit_Parent_SMILES values and Open Babel installation."
        )

    valid_records_df = pd.DataFrame(valid_records)
    excluded_df = pd.DataFrame(excluded_records)
    raw_augmented_df = pd.DataFrame(all_augmented)

    return valid_records_df, bits_by_key, global_bits, excluded_df, raw_augmented_df


def feature_matrix_long(
    valid_records_df: pd.DataFrame,
    bits_by_key: Mapping[Tuple[str, str, int], List[int]],
    global_bits: Sequence[int],
) -> pd.DataFrame:
    features = build_feature_frame_for_records(valid_records_df, bits_by_key, global_bits)
    meta_cols = [
        "Split_ID",
        "Set_Type",
        "_Original_Row_Index",
        "Source_File",
        "Dye_ID",
        "Compound name",
        "RDKit_Parent_InChIKey",
        "Intrinsic_Membrane_Permeability_Status",
        "RDKit_Parent_SMILES",
    ]
    available_meta_cols = [c for c in meta_cols if c in valid_records_df.columns]
    out = pd.concat([valid_records_df[available_meta_cols].reset_index(drop=True), features.reset_index(drop=True)], axis=1)
    return out


def fingerprint_length_check_rows(
    valid_records_df: pd.DataFrame,
    global_bits: Sequence[int],
    openbabel_version: str,
) -> List[Dict[str, object]]:
    rows = []
    final_dim = len(global_bits)
    global_max = max(global_bits) if global_bits else np.nan
    for (split_id, set_type), sub in valid_records_df.groupby(["Split_ID", "Set_Type"], sort=True):
        bit_union = set()
        for value in sub["Observed_Max_Bit_Index_For_Record"].tolist():
            # This column stores per-record max only; observed unique count must be
            # reconstructed from active bit columns elsewhere if needed. Here we
            # use the record-level note and global feature dimension.
            pass
        rows.append(
            {
                "Split_ID": split_id,
                "Set_Type": set_type,
                "Observed_Max_Bit_Index": int(sub["Observed_Max_Bit_Index_For_Record"].max())
                if len(sub) and not pd.isna(sub["Observed_Max_Bit_Index_For_Record"].max())
                else np.nan,
                "Observed_Unique_Bit_Count": np.nan,
                "Final_FP4_Feature_Dimension": final_dim,
                "FP4_Length_Source": "Global observed Open Babel FP4 bit union from all fixed train/test files in this DyePermDB FP4 run",
                "OpenBabel_Version": openbabel_version,
                "Note": (
                    f"Final feature dimension = {final_dim}; global observed maximum bit index = {global_max}. "
                    "No preset FP4 length was used."
                ),
            }
        )
    return rows


def fingerprint_length_check_from_bits(
    valid_records_df: pd.DataFrame,
    bits_by_key: Mapping[Tuple[str, str, int], List[int]],
    global_bits: Sequence[int],
    openbabel_version: str,
) -> pd.DataFrame:
    rows = []
    final_dim = len(global_bits)
    global_max = max(global_bits) if global_bits else np.nan
    for (split_id, set_type), sub in valid_records_df.groupby(["Split_ID", "Set_Type"], sort=True):
        bit_union = set()
        for _, row in sub.iterrows():
            key = (row["Split_ID"], row["Set_Type"], int(row["_Original_Row_Index"]))
            bit_union.update(bits_by_key.get(key, []))
        rows.append(
            {
                "Split_ID": split_id,
                "Set_Type": set_type,
                "Observed_Max_Bit_Index": max(bit_union) if bit_union else np.nan,
                "Observed_Unique_Bit_Count": len(bit_union),
                "Final_FP4_Feature_Dimension": final_dim,
                "FP4_Length_Source": "Global observed Open Babel FP4 bit union from all fixed train/test files in this DyePermDB FP4 run",
                "OpenBabel_Version": openbabel_version,
                "Note": (
                    f"Final feature dimension = {final_dim}; global observed maximum bit index = {global_max}. "
                    "No preset FP4 length was used."
                ),
            }
        )
    return pd.DataFrame(rows)


def get_split_set_data(
    valid_records_df: pd.DataFrame,
    bits_by_key: Mapping[Tuple[str, str, int], List[int]],
    global_bits: Sequence[int],
    split_id: str,
    set_type: str,
    label_col_out: str = "Intrinsic_Membrane_Permeability_Status",
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
    sub = valid_records_df[(valid_records_df["Split_ID"] == split_id) & (valid_records_df["Set_Type"] == set_type)].copy()
    sub = sub.reset_index(drop=True)
    X = build_feature_frame_for_records(sub, bits_by_key, global_bits)
    y = encode_labels(sub[label_col_out].tolist())
    return sub, X, y


def safe_auc(y_true: np.ndarray, score: np.ndarray, metric_func) -> float:
    try:
        if len(np.unique(y_true)) < 2:
            return float("nan")
        return float(metric_func(y_true, score))
    except Exception:
        return float("nan")


def compute_performance_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob_pos: np.ndarray,
) -> Dict[str, object]:
    from sklearn.metrics import (
        accuracy_score,
        average_precision_score,
        balanced_accuracy_score,
        confusion_matrix,
        f1_score,
        matthews_corrcoef,
        roc_auc_score,
    )

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) else float("nan")
    specificity = tn / (tn + fp) if (tn + fp) else float("nan")

    return {
        "ROC_AUC": safe_auc(y_true, y_prob_pos, roc_auc_score),
        "PR_AUC": safe_auc(y_true, y_prob_pos, average_precision_score),
        "Accuracy": float(accuracy_score(y_true, y_pred)) if len(y_true) else float("nan"),
        "Balanced_Accuracy": float(balanced_accuracy_score(y_true, y_pred)) if len(y_true) else float("nan"),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)) if len(y_true) else float("nan"),
        "MCC": float(matthews_corrcoef(y_true, y_pred)) if len(y_true) else float("nan"),
        "Sensitivity_Permeable": float(sensitivity),
        "Specificity_Impermeable": float(specificity),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp),
    }


def compute_curves(
    y_true: np.ndarray,
    y_prob_pos: np.ndarray,
    split_id: str,
    model_name: str,
    set_type: str,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    from sklearn.metrics import precision_recall_curve, roc_curve

    if len(np.unique(y_true)) < 2:
        roc_df = pd.DataFrame(
            [
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Set_Type": set_type,
                    "Threshold": np.nan,
                    "FPR": np.nan,
                    "TPR": np.nan,
                    "Precision": np.nan,
                    "Recall": np.nan,
                    "Note": "ROC curve undefined because only one class is present.",
                }
            ]
        )
        pr_df = pd.DataFrame(
            [
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Set_Type": set_type,
                    "Threshold": np.nan,
                    "FPR": np.nan,
                    "TPR": np.nan,
                    "Precision": np.nan,
                    "Recall": np.nan,
                    "Note": "PR curve undefined because only one class is present.",
                }
            ]
        )
        return roc_df, pr_df

    fpr, tpr, roc_thresholds = roc_curve(y_true, y_prob_pos)
    precision, recall, pr_thresholds = precision_recall_curve(y_true, y_prob_pos)

    roc_df = pd.DataFrame(
        {
            "Split_ID": split_id,
            "Model": model_name,
            "Set_Type": set_type,
            "Threshold": roc_thresholds,
            "FPR": fpr,
            "TPR": tpr,
            "Precision": np.nan,
            "Recall": np.nan,
            "Note": "",
        }
    )
    pr_thresholds_padded = np.append(pr_thresholds, np.nan)
    pr_df = pd.DataFrame(
        {
            "Split_ID": split_id,
            "Model": model_name,
            "Set_Type": set_type,
            "Threshold": pr_thresholds_padded,
            "FPR": np.nan,
            "TPR": np.nan,
            "Precision": precision,
            "Recall": recall,
            "Note": "",
        }
    )
    return roc_df, pr_df


def prediction_rows(
    meta_df: pd.DataFrame,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray,
    split_id: str,
    model_name: str,
    set_type: str,
    random_seed: int,
) -> pd.DataFrame:
    prob_neg = y_prob[:, 0] if y_prob.ndim == 2 and y_prob.shape[1] > 1 else 1 - y_prob
    prob_pos = y_prob[:, 1] if y_prob.ndim == 2 and y_prob.shape[1] > 1 else y_prob
    out = pd.DataFrame(
        {
            "Split_ID": split_id,
            "Random_Seed": random_seed,
            "Model": model_name,
            "Set_Type": set_type,
            "Dye_ID": meta_df["Dye_ID"].values if "Dye_ID" in meta_df.columns else "",
            "Compound name": meta_df["Compound name"].values if "Compound name" in meta_df.columns else "",
            "RDKit_Parent_InChIKey": meta_df["RDKit_Parent_InChIKey"].values
            if "RDKit_Parent_InChIKey" in meta_df.columns
            else "",
            "True_Label": [POSITIVE_LABEL if x == 1 else NEGATIVE_LABEL for x in y_true],
            "Predicted_Label": [POSITIVE_LABEL if x == 1 else NEGATIVE_LABEL for x in y_pred],
            "Probability_Impermeable": prob_neg,
            "Probability_Permeable": prob_pos,
        }
    )
    return out


def summarize_performance(perf_df: pd.DataFrame) -> pd.DataFrame:
    metric_cols = [
        "ROC_AUC",
        "PR_AUC",
        "Accuracy",
        "Balanced_Accuracy",
        "F1",
        "MCC",
        "Sensitivity_Permeable",
        "Specificity_Impermeable",
    ]
    rows = []
    for (model, set_type), sub in perf_df.groupby(["Model", "Set_Type"], sort=True):
        for metric in metric_cols:
            values = pd.to_numeric(sub[metric], errors="coerce")
            rows.append(
                {
                    "Model": model,
                    "Set_Type": set_type,
                    "Metric": metric,
                    "mean": values.mean(),
                    "std": values.std(ddof=1),
                    "min": values.min(),
                    "max": values.max(),
                    "n_splits_with_value": values.notna().sum(),
                }
            )
    return pd.DataFrame(rows)


def save_model(model, path: Path) -> None:
    ensure_dir(path.parent)
    joblib.dump(model, path)


def map_xgb_score_to_bits(score_dict: Mapping[str, float], feature_cols: Sequence[str]) -> Dict[str, float]:
    """
    XGBoost may return keys as real feature names or as f0/f1. Support both.
    """
    out = {col: 0.0 for col in feature_cols}
    col_by_default = {f"f{i}": col for i, col in enumerate(feature_cols)}
    for key, value in score_dict.items():
        if key in out:
            out[key] = float(value)
        elif key in col_by_default:
            out[col_by_default[key]] = float(value)
    return out


def builtin_importance_rows(
    model,
    model_key: str,
    split_id: str,
    feature_cols: Sequence[str],
    bit_indices: Sequence[int],
) -> pd.DataFrame:
    rows = []
    model_name = MODEL_NAME_LONG[model_key]

    if model_key == "RF":
        importances = getattr(model, "feature_importances_", np.zeros(len(feature_cols)))
        for col, bit, value in zip(feature_cols, bit_indices, importances):
            rows.append(
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Importance_Type": "Random Forest feature_importances_",
                    "Bit_Index": int(bit),
                    "Bit_Name": bit_name(bit),
                    "Feature_Column": col,
                    "Importance_Value": float(value),
                }
            )
    elif model_key == "XGBoost":
        booster = model.get_booster()
        gain = map_xgb_score_to_bits(booster.get_score(importance_type="gain"), feature_cols)
        weight = map_xgb_score_to_bits(booster.get_score(importance_type="weight"), feature_cols)
        attr_imp = getattr(model, "feature_importances_", np.zeros(len(feature_cols)))
        for col, bit in zip(feature_cols, bit_indices):
            rows.append(
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Importance_Type": "XGBoost gain",
                    "Bit_Index": int(bit),
                    "Bit_Name": bit_name(bit),
                    "Feature_Column": col,
                    "Importance_Value": float(gain.get(col, 0.0)),
                }
            )
            rows.append(
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Importance_Type": "XGBoost weight",
                    "Bit_Index": int(bit),
                    "Bit_Name": bit_name(bit),
                    "Feature_Column": col,
                    "Importance_Value": float(weight.get(col, 0.0)),
                }
            )
        for col, bit, value in zip(feature_cols, bit_indices, attr_imp):
            rows.append(
                {
                    "Split_ID": split_id,
                    "Model": model_name,
                    "Importance_Type": "XGBoost feature_importances_ attribute",
                    "Bit_Index": int(bit),
                    "Bit_Name": bit_name(bit),
                    "Feature_Column": col,
                    "Importance_Value": float(value),
                }
            )
    out = pd.DataFrame(rows)
    if len(out):
        out["Rank_Within_Split_Model_Type"] = out.groupby(
            ["Split_ID", "Model", "Importance_Type"]
        )["Importance_Value"].rank(method="min", ascending=False)
    return out


def permutation_importance_rows(
    model,
    X: pd.DataFrame,
    y: np.ndarray,
    model_key: str,
    split_id: str,
    set_type: str,
    bit_indices: Sequence[int],
    n_repeats: int,
    random_state: int,
    n_jobs: int,
) -> pd.DataFrame:
    from sklearn.inspection import permutation_importance

    model_name = MODEL_NAME_LONG[model_key]
    feature_cols = list(X.columns)

    base_rows = [
        {
            "Split_ID": split_id,
            "Model": model_name,
            "Set_Type": set_type,
            "Scoring": "roc_auc",
            "n_repeats": n_repeats,
            "Bit_Index": int(bit),
            "Bit_Name": bit_name(bit),
            "Feature_Column": col,
        }
        for bit, col in zip(bit_indices, feature_cols)
    ]

    if len(np.unique(y)) < 2:
        out = pd.DataFrame(base_rows)
        out["Permutation_Importance_Mean"] = np.nan
        out["Permutation_Importance_STD"] = np.nan
        out["Rank_Within_Split_Model_Set"] = np.nan
        out["Note"] = "Permutation importance with ROC-AUC undefined because only one class is present."
        return out

    # Use an explicit ROC-AUC scorer based on predict_proba instead of the
    # string scorer. This keeps the scoring criterion as ROC-AUC while avoiding
    # version-specific estimator-tag issues in some XGBoost/scikit-learn
    # combinations.
    from sklearn.metrics import roc_auc_score

    def _roc_auc_scorer(estimator, X_eval, y_eval):
        prob = estimator.predict_proba(X_eval)[:, 1]
        return roc_auc_score(y_eval, prob)

    result = permutation_importance(
        model,
        X,
        y,
        scoring=_roc_auc_scorer,
        n_repeats=n_repeats,
        random_state=random_state,
        n_jobs=n_jobs,
    )

    out = pd.DataFrame(base_rows)
    out["Permutation_Importance_Mean"] = result.importances_mean
    out["Permutation_Importance_STD"] = result.importances_std
    out["Rank_Within_Split_Model_Set"] = out.groupby(["Split_ID", "Model", "Set_Type"])[
        "Permutation_Importance_Mean"
    ].rank(method="min", ascending=False)
    out["Note"] = ""
    return out


def top10_from_permutation(perm_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (split_id, model, set_type), sub in perm_df.groupby(["Split_ID", "Model", "Set_Type"], sort=True):
        sub2 = sub.sort_values(
            ["Permutation_Importance_Mean", "Permutation_Importance_STD"],
            ascending=[False, True],
            na_position="last",
        ).head(10).copy()
        sub2["TopN"] = range(1, len(sub2) + 1)
        rows.append(sub2)
    if rows:
        return pd.concat(rows, ignore_index=True)
    return pd.DataFrame()


def stability_from_permutation(perm_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Return (model_specific_stability, combined_stability).
    """
    df = perm_df.copy()
    df["Is_Top10"] = df["Rank_Within_Split_Model_Set"] <= 10
    model_rows = []
    for (model, bit_index, bit_name), sub in df.groupby(["Model", "Bit_Index", "Bit_Name"], sort=True):
        vals = pd.to_numeric(sub["Permutation_Importance_Mean"], errors="coerce")
        model_rows.append(
            {
                "Model": model,
                "Bit_Index": int(bit_index),
                "Bit_Name": bit_name,
                "Mean_Permutation_Importance": vals.mean(),
                "STD_Permutation_Importance": vals.std(ddof=1),
                "Min_Permutation_Importance": vals.min(),
                "Max_Permutation_Importance": vals.max(),
                "Top10_Frequency": int(sub["Is_Top10"].sum()),
                "Split_Count": int(sub["Split_ID"].nunique()),
                "Available_Value_Count": int(vals.notna().sum()),
            }
        )
    model_stability = pd.DataFrame(model_rows)
    if len(model_stability):
        model_stability["Stability_Rank_Within_Model"] = model_stability.groupby("Model")[
            "Mean_Permutation_Importance"
        ].rank(method="min", ascending=False)

    combined_rows = []
    if len(model_stability):
        for (bit_index, bit_name), sub in model_stability.groupby(["Bit_Index", "Bit_Name"], sort=True):
            vals = pd.to_numeric(sub["Mean_Permutation_Importance"], errors="coerce")
            combined_rows.append(
                {
                    "Model": "Combined Random Forest + XGBoost",
                    "Bit_Index": int(bit_index),
                    "Bit_Name": bit_name,
                    "Mean_Permutation_Importance": vals.mean(),
                    "STD_Permutation_Importance": vals.std(ddof=1),
                    "Min_Model_Mean_Permutation_Importance": vals.min(),
                    "Max_Model_Mean_Permutation_Importance": vals.max(),
                    "Top10_Frequency_Total": int(sub["Top10_Frequency"].sum()),
                    "Model_Count": int(sub["Model"].nunique()),
                }
            )
    combined_stability = pd.DataFrame(combined_rows)
    if len(combined_stability):
        combined_stability["Stability_Rank_Combined"] = combined_stability[
            "Mean_Permutation_Importance"
        ].rank(method="min", ascending=False)
    return model_stability, combined_stability


def write_excel(path: Path, sheets: Mapping[str, pd.DataFrame]) -> None:
    ensure_dir(path.parent)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            safe_name = str(sheet_name)[:31] if sheet_name else "Sheet1"
            (df if df is not None else pd.DataFrame()).to_excel(writer, sheet_name=safe_name, index=False)


def save_figure_all_formats(fig, base_name: str, fig_paths: Mapping[str, Path], fig_type: str) -> None:
    """
    Save matplotlib figure to TIFF/JPG/PNG at dpi=600 with bbox_inches='tight'.
    fig_type: 'classification' or 'bit_importance'
    """
    if fig_type == "classification":
        targets = [
            (fig_paths["fig_class_tiff"], "tiff"),
            (fig_paths["fig_class_jpg"], "jpg"),
            (fig_paths["fig_class_png"], "png"),
        ]
    elif fig_type == "bit_importance":
        targets = [
            (fig_paths["fig_import_tiff"], "tiff"),
            (fig_paths["fig_import_jpg"], "jpg"),
            (fig_paths["fig_import_png"], "png"),
        ]
    else:
        raise ValueError(f"Unknown fig_type: {fig_type}")

    for folder, ext in targets:
        ensure_dir(folder)
        fig.savefig(folder / f"{base_name}.{ext}", dpi=600, bbox_inches="tight")


def plot_roc_curves(
    roc_df: pd.DataFrame,
    perf_df: pd.DataFrame,
    model_key: str,
    set_type: str,
    fig_paths: Mapping[str, Path],
    filename_base: str,
) -> None:
    import matplotlib.pyplot as plt

    model_name = MODEL_NAME_LONG[model_key]
    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    set_df = roc_df[(roc_df["Model"] == model_name) & (roc_df["Set_Type"] == set_type)].copy()
    for split_id in sorted(set_df["Split_ID"].dropna().unique()):
        sub = set_df[set_df["Split_ID"] == split_id].dropna(subset=["FPR", "TPR"])
        auc_vals = perf_df[
            (perf_df["Model"] == model_name)
            & (perf_df["Set_Type"] == set_type)
            & (perf_df["Split_ID"] == split_id)
        ]["ROC_AUC"]
        auc_val = auc_vals.iloc[0] if len(auc_vals) else np.nan
        label = f"{split_id} (AUC = {auc_val:.3f})" if not pd.isna(auc_val) else f"{split_id} (AUC = NA)"
        if len(sub):
            ax.plot(sub["FPR"], sub["TPR"], linewidth=1.8, label=label)
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.2, color="0.5", label="AUC = 0.5")
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    set_label = "training set" if set_type == "Train" else "test set"
    ax.set_title(f"{model_name} ROC curves for FP4-based permeability classification ({set_label})", fontsize=12)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.grid(True, linewidth=0.4, alpha=0.3)
    ax.legend(loc="lower right", fontsize=8, frameon=True)
    fig.tight_layout()
    save_figure_all_formats(fig, filename_base, fig_paths, "classification")
    plt.close(fig)


def plot_pr_curves(
    pr_df: pd.DataFrame,
    perf_df: pd.DataFrame,
    model_key: str,
    set_type: str,
    fig_paths: Mapping[str, Path],
    filename_base: str,
) -> None:
    import matplotlib.pyplot as plt

    model_name = MODEL_NAME_LONG[model_key]
    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    set_df = pr_df[(pr_df["Model"] == model_name) & (pr_df["Set_Type"] == set_type)].copy()
    for split_id in sorted(set_df["Split_ID"].dropna().unique()):
        sub = set_df[set_df["Split_ID"] == split_id].dropna(subset=["Recall", "Precision"])
        auc_vals = perf_df[
            (perf_df["Model"] == model_name)
            & (perf_df["Set_Type"] == set_type)
            & (perf_df["Split_ID"] == split_id)
        ]["PR_AUC"]
        auc_val = auc_vals.iloc[0] if len(auc_vals) else np.nan
        label = f"{split_id} (PR-AUC = {auc_val:.3f})" if not pd.isna(auc_val) else f"{split_id} (PR-AUC = NA)"
        if len(sub):
            ax.plot(sub["Recall"], sub["Precision"], linewidth=1.8, label=label)
    ax.set_xlabel("Recall", fontsize=11)
    ax.set_ylabel("Precision", fontsize=11)
    set_label = "training set" if set_type == "Train" else "test set"
    ax.set_title(f"{model_name} precision–recall curves for FP4-based permeability classification ({set_label})", fontsize=12)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.grid(True, linewidth=0.4, alpha=0.3)
    ax.legend(loc="lower left", fontsize=8, frameon=True)
    fig.tight_layout()
    save_figure_all_formats(fig, filename_base, fig_paths, "classification")
    plt.close(fig)


def plot_top10_importance_bar(
    df: pd.DataFrame,
    value_col: str,
    title: str,
    xlabel: str,
    filename_base: str,
    fig_paths: Mapping[str, Path],
) -> None:
    import matplotlib.pyplot as plt

    if df is None or df.empty:
        return
    sub = df.sort_values(value_col, ascending=False, na_position="last").head(10).copy()
    sub = sub.iloc[::-1]
    fig_height = max(4.2, 0.38 * len(sub) + 1.6)
    fig, ax = plt.subplots(figsize=(7.2, fig_height))
    ax.barh(sub["Bit_Name"], sub[value_col])
    ax.set_xlabel(xlabel, fontsize=11)
    ax.set_ylabel("FP4 bit", fontsize=11)
    ax.set_title(title, fontsize=12)
    ax.grid(axis="x", linewidth=0.4, alpha=0.3)
    fig.tight_layout()
    save_figure_all_formats(fig, filename_base, fig_paths, "bit_importance")
    plt.close(fig)


def software_environment_row(openbabel_version: str) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "Python_Version": sys.version.replace("\n", " "),
                "Platform": platform.platform(),
                "OpenBabel_Version": openbabel_version,
                "Run_Timestamp": now_text(),
            }
        ]
    )
