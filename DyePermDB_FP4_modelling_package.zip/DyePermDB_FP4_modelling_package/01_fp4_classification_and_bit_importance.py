#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
DyePermDB FP4 molecular fingerprint modelling workflow.

This script performs Open Babel FP4 fingerprint-based binary classification and
FP4 bit-importance analysis for fixed DyePermDB train/test split files. It
calculates FP4 fingerprints from RDKit_Parent_SMILES, trains Random Forest and
XGBoost classifiers, evaluates training and test sets separately, and reports
model-level and permutation-based FP4 bit importance.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

from fp4_modelling_utils import (
    MODEL_NAME_LONG,
    NEGATIVE_LABEL,
    POSITIVE_LABEL,
    bit_name,
    build_fp4_feature_tables,
    builtin_importance_rows,
    compute_curves,
    compute_performance_metrics,
    encode_labels,
    feature_matrix_long,
    fingerprint_length_check_from_bits,
    get_split_set_data,
    init_log,
    internal_bit_col,
    label_distribution_rows,
    leakage_check_rows,
    load_openbabel_pybel,
    log_message,
    make_output_dirs,
    permutation_importance_rows,
    plot_pr_curves,
    plot_roc_curves,
    plot_top10_importance_bar,
    prediction_rows,
    read_split_files,
    save_model,
    software_environment_row,
    split_file_prefix,
    split_id_from_number,
    stability_from_permutation,
    summarize_performance,
    top10_from_permutation,
    write_excel,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "DyePermDB Open Babel FP4 fingerprint modelling workflow for fixed train/test splits. "
            "The workflow performs binary classification and FP4 bit importance analysis."
        )
    )
    parser.add_argument(
        "--input_dir",
        type=str,
        default=".",
        help="Directory containing split_01_train.xlsx ... split_05_test.xlsx.",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="output",
        help="Output directory. Default: output",
    )
    parser.add_argument(
        "--splits",
        type=str,
        default="1,2,3,4,5",
        help="Comma-separated split numbers to process. Default: 1,2,3,4,5",
    )
    parser.add_argument("--id_col", type=str, default="Dye_ID")
    parser.add_argument("--name_col", type=str, default="Compound name")
    parser.add_argument(
        "--label_col",
        type=str,
        default="Intrinsic_Membrane_Permeability_Status",
    )
    parser.add_argument(
        "--context_col",
        type=str,
        default="Permeability_Dependency_Context",
    )
    parser.add_argument(
        "--smiles_col",
        type=str,
        default="RDKit_Parent_SMILES",
    )
    parser.add_argument(
        "--inchikey_col",
        type=str,
        default="RDKit_Parent_InChIKey",
    )
    parser.add_argument("--pmid_col", type=str, default="Reference_PMID")
    parser.add_argument("--title_col", type=str, default="Reference_Title")
    parser.add_argument("--random_seed", type=int, default=20250603)
    parser.add_argument("--n_repeats", type=int, default=30)
    parser.add_argument("--n_jobs", type=int, default=-1)
    parser.add_argument("--rf_n_estimators", type=int, default=500)
    parser.add_argument("--rf_max_depth", type=int, default=0, help="0 means None.")
    parser.add_argument("--xgb_n_estimators", type=int, default=300)
    parser.add_argument("--xgb_learning_rate", type=float, default=0.05)
    parser.add_argument("--xgb_max_depth", type=int, default=3)
    parser.add_argument("--xgb_subsample", type=float, default=0.8)
    parser.add_argument("--xgb_colsample_bytree", type=float, default=0.8)
    return parser.parse_args()


def import_xgboost():
    try:
        from xgboost import XGBClassifier
    except Exception as exc:
        raise ImportError(
            "xgboost is required for this workflow. Install it with conda or pip, "
            "for example: conda install -c conda-forge xgboost. "
            f"Original import error: {exc}"
        ) from exc
    return XGBClassifier


def train_models(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    args: argparse.Namespace,
):
    XGBClassifier = import_xgboost()

    if len(np.unique(y_train)) < 2:
        raise ValueError(
            "Training set contains only one class after valid-label and FP4-generation filtering. "
            "The workflow preserves supplied split assignments and labels; please inspect excluded records and split label distribution."
        )

    pos_count = int(np.sum(y_train == 1))
    neg_count = int(np.sum(y_train == 0))
    scale_pos_weight = neg_count / pos_count if pos_count else 1.0

    rf_max_depth = None if args.rf_max_depth == 0 else args.rf_max_depth
    rf = RandomForestClassifier(
        n_estimators=args.rf_n_estimators,
        random_state=args.random_seed,
        class_weight="balanced",
        max_depth=rf_max_depth,
        n_jobs=args.n_jobs,
    )

    xgb = XGBClassifier(
        n_estimators=args.xgb_n_estimators,
        learning_rate=args.xgb_learning_rate,
        max_depth=args.xgb_max_depth,
        subsample=args.xgb_subsample,
        colsample_bytree=args.xgb_colsample_bytree,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=args.random_seed,
        n_jobs=args.n_jobs,
        scale_pos_weight=scale_pos_weight,
    )

    rf.fit(X_train, y_train)
    xgb.fit(X_train, y_train)

    return {"RF": rf, "XGBoost": xgb}


def evaluate_model_on_set(
    model,
    model_key: str,
    X: pd.DataFrame,
    y: np.ndarray,
    meta: pd.DataFrame,
    split_id: str,
    set_type: str,
    random_seed: int,
):
    model_name = MODEL_NAME_LONG[model_key]
    y_prob = model.predict_proba(X)
    y_prob_pos = y_prob[:, 1]
    y_pred = (y_prob_pos >= 0.5).astype(int)

    metrics = compute_performance_metrics(y, y_pred, y_prob_pos)
    perf_row = {
        "Split_ID": split_id,
        "Random_Seed": random_seed,
        "Model": model_name,
        "Set_Type": set_type,
        "Sample_Size": int(len(y)),
        "Permeable_Count": int(np.sum(y == 1)),
        "Impermeable_Count": int(np.sum(y == 0)),
    }
    perf_row.update(metrics)

    pred_df = prediction_rows(meta, y, y_pred, y_prob, split_id, model_name, set_type, random_seed)
    roc_df, pr_df = compute_curves(y, y_prob_pos, split_id, model_name, set_type)

    cm_row = {
        "Split_ID": split_id,
        "Random_Seed": random_seed,
        "Model": model_name,
        "Set_Type": set_type,
        "Sample_Size": int(len(y)),
        "TN": int(metrics["TN"]),
        "FP": int(metrics["FP"]),
        "FN": int(metrics["FN"]),
        "TP": int(metrics["TP"]),
        "Matrix_Order": "Rows=true class [Impermeable, Permeable]; columns=predicted class [Impermeable, Permeable]",
    }

    return perf_row, pred_df, roc_df, pr_df, cm_row


def save_classification_outputs(
    paths: Dict[str, Path],
    rf_perf: pd.DataFrame,
    xgb_perf: pd.DataFrame,
    rf_summary: pd.DataFrame,
    xgb_summary: pd.DataFrame,
    rf_pred: pd.DataFrame,
    xgb_pred: pd.DataFrame,
    rf_cm: pd.DataFrame,
    xgb_cm: pd.DataFrame,
    rf_roc: pd.DataFrame,
    xgb_roc: pd.DataFrame,
    rf_pr: pd.DataFrame,
    xgb_pr: pd.DataFrame,
    comparison_df: pd.DataFrame,
    feature_matrix_df: pd.DataFrame,
    excluded_df: pd.DataFrame,
    leakage_df: pd.DataFrame,
    label_dist_df: pd.DataFrame,
    length_check_df: pd.DataFrame,
    env_df: pd.DataFrame,
) -> None:
    out_dir = paths["classification"]

    write_excel(out_dir / "fp4_RF_performance_by_split.xlsx", {"RF_performance_by_split": rf_perf})
    write_excel(out_dir / "fp4_RF_performance_summary.xlsx", {"RF_performance_summary": rf_summary})
    write_excel(out_dir / "fp4_RF_prediction_results_by_split.xlsx", {"RF_predictions": rf_pred})
    write_excel(out_dir / "fp4_RF_confusion_matrix_summary.xlsx", {"RF_confusion_matrix": rf_cm})
    write_excel(out_dir / "fp4_RF_roc_curve_data.xlsx", {"RF_ROC_curve_data": rf_roc})
    write_excel(out_dir / "fp4_RF_pr_curve_data.xlsx", {"RF_PR_curve_data": rf_pr})

    write_excel(out_dir / "fp4_XGBoost_performance_by_split.xlsx", {"XGBoost_performance_by_split": xgb_perf})
    write_excel(out_dir / "fp4_XGBoost_performance_summary.xlsx", {"XGBoost_performance_summary": xgb_summary})
    write_excel(out_dir / "fp4_XGBoost_prediction_results_by_split.xlsx", {"XGBoost_predictions": xgb_pred})
    write_excel(out_dir / "fp4_XGBoost_confusion_matrix_summary.xlsx", {"XGBoost_confusion_matrix": xgb_cm})
    write_excel(out_dir / "fp4_XGBoost_roc_curve_data.xlsx", {"XGBoost_ROC_curve_data": xgb_roc})
    write_excel(out_dir / "fp4_XGBoost_pr_curve_data.xlsx", {"XGBoost_PR_curve_data": xgb_pr})

    write_excel(out_dir / "fp4_RF_vs_XGBoost_performance_comparison.xlsx", {"RF_vs_XGBoost": comparison_df})
    write_excel(out_dir / "fp4_feature_matrix_by_split.xlsx", {"FP4_feature_matrix": feature_matrix_df})
    write_excel(out_dir / "fp4_excluded_records_with_reasons.xlsx", {"Excluded_records": excluded_df})
    write_excel(out_dir / "fp4_leakage_check.xlsx", {"Leakage_check": leakage_df})
    write_excel(out_dir / "fp4_split_label_distribution.xlsx", {"Label_distribution": label_dist_df})
    write_excel(out_dir / "fp4_fingerprint_length_check.xlsx", {"FP4_length_check": length_check_df})
    write_excel(out_dir / "fp4_software_environment.xlsx", {"Software_environment": env_df})


def save_importance_outputs(
    paths: Dict[str, Path],
    builtin_df: pd.DataFrame,
    perm_train_df: pd.DataFrame,
    perm_test_df: pd.DataFrame,
    top10_train_df: pd.DataFrame,
    top10_test_df: pd.DataFrame,
    stability_train_df: pd.DataFrame,
    stability_test_df: pd.DataFrame,
    stable_train_summary_df: pd.DataFrame,
    stable_test_summary_df: pd.DataFrame,
) -> None:
    out_dir = paths["importance"]

    write_excel(out_dir / "fp4_builtin_bit_importance_by_split.xlsx", {"Built_in_importance": builtin_df})
    write_excel(out_dir / "fp4_permutation_importance_train_by_split.xlsx", {"Train_permutation": perm_train_df})
    write_excel(out_dir / "fp4_permutation_importance_test_by_split.xlsx", {"Test_permutation": perm_test_df})
    write_excel(out_dir / "fp4_top10_bits_train_by_split.xlsx", {"Train_top10_bits": top10_train_df})
    write_excel(out_dir / "fp4_top10_bits_test_by_split.xlsx", {"Test_top10_bits": top10_test_df})
    write_excel(out_dir / "fp4_bit_importance_stability_train.xlsx", {"Train_stability": stability_train_df})
    write_excel(out_dir / "fp4_bit_importance_stability_test.xlsx", {"Test_stability": stability_test_df})
    write_excel(out_dir / "stable_fp4_bits_train_summary.xlsx", {"Stable_train_summary": stable_train_summary_df})
    write_excel(out_dir / "stable_fp4_bits_test_summary.xlsx", {"Stable_test_summary": stable_test_summary_df})


def plot_classification_figures(
    paths: Dict[str, Path],
    rf_perf: pd.DataFrame,
    xgb_perf: pd.DataFrame,
    rf_roc: pd.DataFrame,
    xgb_roc: pd.DataFrame,
    rf_pr: pd.DataFrame,
    xgb_pr: pd.DataFrame,
) -> None:
    plot_roc_curves(rf_roc, rf_perf, "RF", "Train", paths, "RF_ROC_curves_train")
    plot_roc_curves(rf_roc, rf_perf, "RF", "Test", paths, "RF_ROC_curves_test")
    plot_pr_curves(rf_pr, rf_perf, "RF", "Train", paths, "RF_PR_curves_train")
    plot_pr_curves(rf_pr, rf_perf, "RF", "Test", paths, "RF_PR_curves_test")

    plot_roc_curves(xgb_roc, xgb_perf, "XGBoost", "Train", paths, "XGBoost_ROC_curves_train")
    plot_roc_curves(xgb_roc, xgb_perf, "XGBoost", "Test", paths, "XGBoost_ROC_curves_test")
    plot_pr_curves(xgb_pr, xgb_perf, "XGBoost", "Train", paths, "XGBoost_PR_curves_train")
    plot_pr_curves(xgb_pr, xgb_perf, "XGBoost", "Test", paths, "XGBoost_PR_curves_test")


def plot_importance_figures(
    paths: Dict[str, Path],
    top10_train_df: pd.DataFrame,
    top10_test_df: pd.DataFrame,
    stability_train_df: pd.DataFrame,
    stability_test_df: pd.DataFrame,
    stable_train_summary_df: pd.DataFrame,
    stable_test_summary_df: pd.DataFrame,
) -> None:
    # Per split, per model, Train/Test Top 10 permutation importance plots.
    for set_type, top_df in [("train", top10_train_df), ("test", top10_test_df)]:
        if top_df is None or top_df.empty:
            continue
        for (split_id, model), sub in top_df.groupby(["Split_ID", "Model"], sort=True):
            split_file = split_id.lower().replace(" ", "_")
            model_title = "Random Forest" if str(model).casefold() == "Random Forest".casefold() else str(model)
            model_file = "RF" if model_title == "Random Forest" else "XGBoost"
            filename = f"{split_file}_{model_file}_{set_type}_top10_fp4_bits"
            title_set = "Training set" if set_type == "train" else "Test set"
            title = f"Top FP4 bits by permutation importance: {model_title}, {split_id} ({title_set})"
            plot_top10_importance_bar(
                sub,
                "Permutation_Importance_Mean",
                title,
                "Permutation importance (ROC-AUC decrease)",
                filename,
                paths,
            )

    # Recurrent model-specific plots
    for set_type, stab_df in [("train", stability_train_df), ("test", stability_test_df)]:
        if stab_df is None or stab_df.empty:
            continue
        for model, sub in stab_df.groupby("Model", sort=True):
            model_title = "Random Forest" if str(model).casefold() == "Random Forest".casefold() else str(model)
            model_file = "RF" if model_title == "Random Forest" else "XGBoost"
            filename = f"stable_{model_file}_{set_type}_fp4_bits"
            title_set = "Training set" if set_type == "train" else "Test set"
            title = f"Recurrent FP4 bits across splits: {model_title} ({title_set})"
            plot_top10_importance_bar(
                sub,
                "Mean_Permutation_Importance",
                title,
                "Mean permutation importance (ROC-AUC decrease)",
                filename,
                paths,
            )

    # Recurrent combined plots
    for set_type, combined_df in [("train", stable_train_summary_df), ("test", stable_test_summary_df)]:
        if combined_df is None or combined_df.empty:
            continue
        filename = f"stable_combined_{set_type}_fp4_bits"
        title_set = "Training set" if set_type == "train" else "Test set"
        title = f"Recurrent FP4 bits across models and splits ({title_set})"
        plot_top10_importance_bar(
            combined_df,
            "Mean_Permutation_Importance",
            title,
            "Mean permutation importance (ROC-AUC decrease)",
            filename,
            paths,
        )


def main() -> None:
    args = parse_args()
    input_dir = Path(args.input_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    paths = make_output_dirs(output_dir)
    log_path = init_log(output_dir)

    log_message(log_path, "DyePermDB FP4 modelling workflow initialized.")
    log_message(log_path, f"Input directory: {input_dir}")
    log_message(log_path, f"Output directory: {output_dir}")
    log_message(log_path, "Fixed train/test split files will be used without resplitting or label modification.")

    pybel, _ob, openbabel_version = load_openbabel_pybel()
    log_message(log_path, f"Open Babel / pybel loaded. Version: {openbabel_version}")

    # Check the XGBoost dependency before model fitting.
    import_xgboost()
    log_message(log_path, "xgboost successfully imported.")

    split_numbers = [int(x.strip()) for x in args.splits.split(",") if x.strip()]
    required_columns = [
        args.id_col,
        args.name_col,
        args.label_col,
        args.context_col,
        args.smiles_col,
        args.inchikey_col,
        args.pmid_col,
        args.title_col,
    ]

    split_data = read_split_files(input_dir, split_numbers, required_columns)
    log_message(log_path, f"Read {len(split_data)} fixed train/test files.")

    # Label distribution and leakage check before any FP4 filtering.
    label_rows = []
    leakage_rows_all = []
    for split_number in split_numbers:
        split_id = split_id_from_number(split_number)
        train_df = split_data[(split_id, "Train")]
        test_df = split_data[(split_id, "Test")]
        label_rows.extend(label_distribution_rows(train_df, args.label_col, split_id, "Train"))
        label_rows.extend(label_distribution_rows(test_df, args.label_col, split_id, "Test"))
        leakage_rows_all.extend(leakage_check_rows(train_df, test_df, args.inchikey_col, split_id))
    label_dist_df = pd.DataFrame(label_rows)
    leakage_df = pd.DataFrame(leakage_rows_all)

    log_message(log_path, "Calculating Open Babel FP4 fingerprints for all fixed split records.")
    valid_records_df, bits_by_key, global_bits, excluded_df, raw_augmented_df = build_fp4_feature_tables(
        split_data=split_data,
        pybel_module=pybel,
        label_col=args.label_col,
        smiles_col=args.smiles_col,
        id_col=args.id_col,
        name_col=args.name_col,
        inchikey_col=args.inchikey_col,
        pmid_col=args.pmid_col,
        title_col=args.title_col,
    )

    feature_cols = [internal_bit_col(bit) for bit in global_bits]
    log_message(
        log_path,
        (
            f"Open Babel FP4 global observed bit union built. "
            f"Observed unique bits: {len(global_bits)}; "
            f"observed max bit index: {max(global_bits) if global_bits else 'NA'}. "
            "No preset FP4 length was used."
        ),
    )

    length_check_df = fingerprint_length_check_from_bits(
        valid_records_df,
        bits_by_key,
        global_bits,
        openbabel_version,
    )
    feature_matrix_df = feature_matrix_long(valid_records_df, bits_by_key, global_bits)
    env_df = software_environment_row(openbabel_version)

    all_perf_rows = []
    all_pred_dfs = []
    all_roc_dfs = []
    all_pr_dfs = []
    all_cm_rows = []
    all_builtin_dfs = []
    perm_train_dfs = []
    perm_test_dfs = []

    for split_number in split_numbers:
        split_id = split_id_from_number(split_number)
        log_message(log_path, f"Processing {split_id}.")

        train_meta, X_train, y_train = get_split_set_data(
            valid_records_df, bits_by_key, global_bits, split_id, "Train"
        )
        test_meta, X_test, y_test = get_split_set_data(
            valid_records_df, bits_by_key, global_bits, split_id, "Test"
        )

        # Keep DataFrame column names for XGBoost feature names and permutation outputs.
        X_train = X_train[feature_cols]
        X_test = X_test[feature_cols]

        log_message(
            log_path,
            (
                f"{split_id}: Train n={len(y_train)} "
                f"(Permeable={int(np.sum(y_train == 1))}, Impermeable={int(np.sum(y_train == 0))}); "
                f"Test n={len(y_test)} "
                f"(Permeable={int(np.sum(y_test == 1))}, Impermeable={int(np.sum(y_test == 0))})."
            ),
        )

        models = train_models(X_train, y_train, args)

        for model_key, model in models.items():
            model_name = MODEL_NAME_LONG[model_key]
            log_message(log_path, f"{split_id}: Evaluating {model_name} on Train and Test sets.")

            # Save trained model.
            model_file_key = "RF" if model_key == "RF" else "XGBoost"
            model_path = paths["models"] / f"{split_file_prefix(split_number)}_{model_file_key}.pkl"
            save_model(model, model_path)

            # Classification evaluation: Train and Test.
            for set_type, X, y, meta in [
                ("Train", X_train, y_train, train_meta),
                ("Test", X_test, y_test, test_meta),
            ]:
                perf_row, pred_df, roc_df, pr_df, cm_row = evaluate_model_on_set(
                    model=model,
                    model_key=model_key,
                    X=X,
                    y=y,
                    meta=meta,
                    split_id=split_id,
                    set_type=set_type,
                    random_seed=args.random_seed,
                )
                all_perf_rows.append(perf_row)
                all_pred_dfs.append(pred_df)
                all_roc_dfs.append(roc_df)
                all_pr_dfs.append(pr_df)
                all_cm_rows.append(cm_row)

            # Built-in model-level bit importance.
            all_builtin_dfs.append(
                builtin_importance_rows(
                    model=model,
                    model_key=model_key,
                    split_id=split_id,
                    feature_cols=feature_cols,
                    bit_indices=global_bits,
                )
            )

            # Permutation importance: Train and Test separately.
            log_message(
                log_path,
                f"{split_id}: Calculating {model_name} Train permutation importance (n_repeats={args.n_repeats}).",
            )
            perm_train_dfs.append(
                permutation_importance_rows(
                    model=model,
                    X=X_train,
                    y=y_train,
                    model_key=model_key,
                    split_id=split_id,
                    set_type="Train",
                    bit_indices=global_bits,
                    n_repeats=args.n_repeats,
                    random_state=args.random_seed,
                    n_jobs=args.n_jobs,
                )
            )
            log_message(
                log_path,
                f"{split_id}: Calculating {model_name} Test permutation importance (n_repeats={args.n_repeats}).",
            )
            perm_test_dfs.append(
                permutation_importance_rows(
                    model=model,
                    X=X_test,
                    y=y_test,
                    model_key=model_key,
                    split_id=split_id,
                    set_type="Test",
                    bit_indices=global_bits,
                    n_repeats=args.n_repeats,
                    random_state=args.random_seed,
                    n_jobs=args.n_jobs,
                )
            )

    perf_df = pd.DataFrame(all_perf_rows)
    pred_df_all = pd.concat(all_pred_dfs, ignore_index=True) if all_pred_dfs else pd.DataFrame()
    roc_df_all = pd.concat(all_roc_dfs, ignore_index=True) if all_roc_dfs else pd.DataFrame()
    pr_df_all = pd.concat(all_pr_dfs, ignore_index=True) if all_pr_dfs else pd.DataFrame()
    cm_df_all = pd.DataFrame(all_cm_rows)
    builtin_df = pd.concat(all_builtin_dfs, ignore_index=True) if all_builtin_dfs else pd.DataFrame()
    perm_train_df = pd.concat(perm_train_dfs, ignore_index=True) if perm_train_dfs else pd.DataFrame()
    perm_test_df = pd.concat(perm_test_dfs, ignore_index=True) if perm_test_dfs else pd.DataFrame()

    rf_perf = perf_df[perf_df["Model"] == "Random Forest"].copy()
    xgb_perf = perf_df[perf_df["Model"] == "XGBoost"].copy()
    rf_summary = summarize_performance(rf_perf)
    xgb_summary = summarize_performance(xgb_perf)

    rf_pred = pred_df_all[pred_df_all["Model"] == "Random Forest"].copy()
    xgb_pred = pred_df_all[pred_df_all["Model"] == "XGBoost"].copy()
    rf_cm = cm_df_all[cm_df_all["Model"] == "Random Forest"].copy()
    xgb_cm = cm_df_all[cm_df_all["Model"] == "XGBoost"].copy()
    rf_roc = roc_df_all[roc_df_all["Model"] == "Random Forest"].copy()
    xgb_roc = roc_df_all[roc_df_all["Model"] == "XGBoost"].copy()
    rf_pr = pr_df_all[pr_df_all["Model"] == "Random Forest"].copy()
    xgb_pr = pr_df_all[pr_df_all["Model"] == "XGBoost"].copy()

    comparison_df = perf_df.copy()

    top10_train_df = top10_from_permutation(perm_train_df)
    top10_test_df = top10_from_permutation(perm_test_df)
    stability_train_model_df, stability_train_combined_df = stability_from_permutation(perm_train_df)
    stability_test_model_df, stability_test_combined_df = stability_from_permutation(perm_test_df)

    # Recurrent-bit summary files combine model-specific and combined rows, but preserve Model column.
    stable_train_summary_df = pd.concat(
        [stability_train_model_df, stability_train_combined_df], ignore_index=True, sort=False
    )
    stable_test_summary_df = pd.concat(
        [stability_test_model_df, stability_test_combined_df], ignore_index=True, sort=False
    )

    log_message(log_path, "Saving classification output workbooks.")
    save_classification_outputs(
        paths=paths,
        rf_perf=rf_perf,
        xgb_perf=xgb_perf,
        rf_summary=rf_summary,
        xgb_summary=xgb_summary,
        rf_pred=rf_pred,
        xgb_pred=xgb_pred,
        rf_cm=rf_cm,
        xgb_cm=xgb_cm,
        rf_roc=rf_roc,
        xgb_roc=xgb_roc,
        rf_pr=rf_pr,
        xgb_pr=xgb_pr,
        comparison_df=comparison_df,
        feature_matrix_df=feature_matrix_df,
        excluded_df=excluded_df,
        leakage_df=leakage_df,
        label_dist_df=label_dist_df,
        length_check_df=length_check_df,
        env_df=env_df,
    )

    log_message(log_path, "Saving FP4 bit importance output workbooks.")
    save_importance_outputs(
        paths=paths,
        builtin_df=builtin_df,
        perm_train_df=perm_train_df,
        perm_test_df=perm_test_df,
        top10_train_df=top10_train_df,
        top10_test_df=top10_test_df,
        stability_train_df=stability_train_model_df,
        stability_test_df=stability_test_model_df,
        stable_train_summary_df=stable_train_summary_df,
        stable_test_summary_df=stable_test_summary_df,
    )

    log_message(log_path, "Generating classification ROC/PR figures.")
    plot_classification_figures(paths, rf_perf, xgb_perf, rf_roc, xgb_roc, rf_pr, xgb_pr)

    log_message(log_path, "Generating FP4 bit importance figures.")
    plot_importance_figures(
        paths=paths,
        top10_train_df=top10_train_df,
        top10_test_df=top10_test_df,
        stability_train_df=stability_train_model_df,
        stability_test_df=stability_test_model_df,
        stable_train_summary_df=stable_train_summary_df,
        stable_test_summary_df=stable_test_summary_df,
    )

    run_log = paths["classification"] / "fp4_modelling_run_log.txt"
    run_log.write_text(log_path.read_text(encoding="utf-8"), encoding="utf-8")

    log_message(log_path, "DyePermDB FP4 workflow completed successfully.")
    run_log.write_text(log_path.read_text(encoding="utf-8"), encoding="utf-8")


if __name__ == "__main__":
    main()
